var storedClientMessages=[];

var request = new XMLHttpRequest();
request.open("GET", "config.txt", false);
request.send(null);
var returnValue = request.responseText;

var host = returnValue.split("\n")[0];
var port = returnValue.split("\n")[1];

var socket = io.connect(host+':'+port,{
		'sync disconnect on unload':true,
		'connect timeout':200,
		'reconnection delay ':100,
	}
); 

socket.on('connect',function() {
  console.log('Client has connected to the server!');
   gameScreen = SceneManager.getInstance().currentScene;
   if(gameScreen){
		gameScreen.setServerConnected(true);
	}else{
		storedClientMessages.push(JSON.stringify({"connect":true}));
	}
});


socket.on('message',function(data) {
	reactToSocketMessage(data);
});

reactToSocketMessage=function(data){
	data = JSON.parse(data);
	var allow=false;
	for(var prop in data){ allow=true; break;}
	//Objects without data are useless.
	if(allow==false)
		return;
	console.log('Received a message from the server!',data);
	screen = SceneManager.getInstance().currentScene;
	if(screen){
		if(data["connect"]){
			screen.setServerConnected(true);
		} else if(data["disconnect"]){
			screen.setServerConnected(false);
		}
		if(screen.getIdentifier()=="Game"){
			if(data["newPlayer"]){
				screen.addPlayer(data["newPlayer"]);
			}else if(data["playerLeft"]){
				screen.destroyPlayer(data["playerLeft"]);
			}
			else if(data["moveTo"]){
				if(!screen.players[data["id"]] || (screen.players[data["id"]] && screen.players[data["id"]].isWalking ==false)){
					screen.movePlayer(data["id"],data["moveTo"]);
				}else{
					storedClientMessages.push(JSON.stringify(data));
				}
			} else if(data["chatMessage"]){
				screen.addChatMessage(data["chatMessage"],true);
			}
			else if(data["coinflip"]){
				screen.addChatMessage(data["coinflip"],true);
			} 
			else if(data["diceroll"]){
				screen.addChatMessage(data["diceroll"],true);
			} 
			else if(data["dance"]){
				screen.addChatMessage(data["dance"],true);
			} 
			else if(data["afk"]){
				screen.changePlayerStatus(data["afk"],"AFK");
			} 
		} else if(screen.getIdentifier()=="Login"){
			if(data["login_success"]){
				screen.onLoginSuccess();
			} else if(data["login_fail"]){
				screen.onLoginFailed(data["login_fail"]);
			}
		}
	} else{
		storedClientMessages.push(JSON.stringify(data));
	}
};



socket.on('disconnect',function() {
  console.log('The client has disconnected!');
  screen = SceneManager.getInstance().currentScene;
  if(screen){
		screen.setServerConnected(false);
  }	else{
		storedClientMessages.push(JSON.stringify({"disconnect":true}));
	}
});

// Sends a message to the server via sockets
function sendMessageToServer(message) {
  socket.send(JSON.stringify(message));
};