var GameMap=cc.Class.extend({
	instance:null,
	
	setupTiles:function(tileData,tiles){
		for(var i in tiles){
			if(i.substring(0,4)=="tile"){
				for(var k=0;k<tiles[i].layers.length;k++){
					tiles[i].popLayer();
				}
				for(var j in tileData[i]){	
					if(tileData[i]){
						tiles[i].pushLayer(tileData[i][j].texture,tileData[i][j].spriteframe,tileData[i][j].spriteframe,tileData[i][j].type);
					}
				}
			}
		}
	}
	
});

GameMap.create=function(){
	if(!this.instance){
		this.instance = new GameMap();
	}
	return this.instance;
};