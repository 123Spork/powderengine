Popup = Scene.extend({
	prevMovPos:null,

	init:function(){
		this.sceneIdentifier = this.getIdentifier();
		this._super();	
		SceneManager.setActiveScene(this);
		this.setupPopup();
		this.setTouchPriority(-50);
	},

	exitButtonPressed:function(){
		this.removeFromParent();
	},

	onTouchBegan:function(touch){
		if(cc.rectContainsPoint(cc.rect(this.panels.getPosition().x,this.panels.getPosition().y+this.panels["control_panel"].getPosition().y,this.panels["control_panel"].getContentSize().width,this.panels["control_panel"].getContentSize().height),touch._point)){
			this.prevMovPos=this.panels.convertTouchToNodeSpace(touch);
			return true;
		}
		return false;
	},

	onTouchMoved:function(touch){
		if(this.prevMovPos){
			var pt=touch._point;
			this.panels.setPosition(cc.p(pt.x-this.prevMovPos.x,pt.y-this.prevMovPos.y));
			return true;
		}
	},

	onTouchEnded:function(touch){
		this.prevMovPos=null;
	},

	setupPopup:function(){
		cc.log("Ovveride setupPopup");
	},

	getIdentifier:function(){
		cc.log("No id given... using default 'Popup'");
		return "Popup";
	},

	onTouchEnded:function(touch){
	},

});

InventoryPopup = Popup.extend({

	getIdentifier:function(){
		return "Inventory";
	},
	
	getLayoutObject:function(){
		var inventory_panel = {};
		for(var x=0;x<5;x++){
			for(var y=0;y<8;y++){
				inventory_panel[(5 * y + x)+""]={
					size: cc.size(32,32),
					bg: cc.c4b(140,140,140,200),
					position: cc.p((x*40)+8,(((8-1)-y)*40)+8)
				};
			}
		}
		
		return { 
			"panels":{
				position:cc.p(300,200),
				children:{	
					"main_panel":{
						anchorPoint:cc.p(0,0),
						size: cc.size(208,328),
						bg: cc.c4b(255,255,255,200),
						children: inventory_panel,
					},
					"control_panel":{
						anchorPoint:cc.p(0,0),
						position: cc.p(0,328),
						size: cc.size(208,32),
						bg: cc.c4b(255,0,0,200),
						children:{	
							"header":{
								label:"Inventory",
								fontSize:20,
								anchorPoint:cc.p(0,0.5),
								position:cc.p(8,16),
							}
						}
					},
				}	
			}
		};
	},
});

EquipmentPopup = Popup.extend({

	getIdentifier:function(){
		return "Equipment";
	},
	
	getLayoutObject:function(){
		var itemBox = {
			size: cc.size(32,32),
			bg: cc.c4b(140,140,140,200),
		};
		var equipment_panel = {
			"head": merge_objects(itemBox,{ position:cc.p(88,128)}),
			"body": merge_objects(itemBox,{ position: cc.p(88,88)}),
			"legs": merge_objects(itemBox,{ position: cc.p(88,48)}),
			"feet": merge_objects(itemBox,{ position: cc.p(88,8)}),
			"weapon": merge_objects(itemBox,{ position: cc.p(48,88)}),
			"shield": merge_objects(itemBox,{ position: cc.p(128,88)}),
			"ammo": merge_objects(itemBox,{ position: cc.p(8,128)}),
		}
		
		return {
			"panels":{
				position:cc.p(100,300),
				children:{	
					"main_panel":{
						anchorPoint:cc.p(0,0),
						size: cc.size(168,168),
						bg: cc.c4b(255,255,255,200),
						children: equipment_panel,
					},
					"control_panel":{
						anchorPoint:cc.p(0,0),
						position: cc.p(0,168),
						size: cc.size(168,32),
						bg: cc.c4b(255,0,0,200),
						children:{	
							"header":{
								label:"Equipment",
								fontSize:20,
								anchorPoint:cc.p(0,0.5),
								position:cc.p(8,16),
							}
						}
					},
				}	
			}
		};
	},

});

MapEditor = Popup.extend({
	map:null,
	editMode:"tiles",
	lastTile:null,
	currentLayer:"ground1",
	currentTexture:tileTextureList[0]["name"],
	currentTextureNumber:0,
	
	getLayoutObject:function(){
		return { "panels":{
				position:cc.p(300,10),
				children:{	
					"main_panel":{
						anchorPoint:cc.p(0,0),
						position: cc.p(0,0),
						size: cc.size(420,380),
						bg: cc.c4b(0,0,100,120),
						children: {
							"tab1":{
								children:{
									"tiles" : {
										anchorPoint:cc.p(0,1),
										position:cc.p(16,336),
										texture:tileTextureList[0]["name"],
									},
									
									"textureleftbtn" : {
										position:cc.p(360,344),
										size:cc.size(16,32),
										bg: cc.c4b(255,255,255,255),
										anchorPoint:cc.p(0,0),
										children:{
											"text":{
												label:"<<",
												fontSize:12,
												anchorPoint:cc.p(0.5,0.5),
												position:cc.p(8,16),
												color:cc.c3b(0,0,0),
											}
										}
									},
									"texturerightbtn" : {
										position:cc.p(472,344),
										size:cc.size(16,32),
										bg: cc.c4b(255,255,255,255),
										anchorPoint:cc.p(0,0),
										children:{
											"text":{
												label:">>",
												fontSize:12,
												anchorPoint:cc.p(0.5,0.5),
												position:cc.p(8,16),
												color:cc.c3b(0,0,0),
											}
										}
									},
									"textureName" : {
										position:cc.p(376,344),
										size:cc.size(96,32),
										bg: cc.c4b(255,255,255,170),
										anchorPoint:cc.p(0,0),
										children:{
											"text":{
												label:tileTextureList[0]["name"],
												fontSize:12,
												anchorPoint:cc.p(0.5,0.5),
												position:cc.p(48,16),
												color:cc.c3b(0,0,0),
											}
										}
									},
									
									"deletebtn" : {
										position:cc.p(360,308),
										size:cc.size(60,32),
										bg: cc.c4b(255,255,255,255),
										anchorPoint:cc.p(0,0),
										children:{
											"text":{
												label:"Erase",
												fontSize:12,
												anchorPoint:cc.p(0.5,0.5),
												position:cc.p(32,16),
												color:cc.c3b(0,0,0),
											}
										}
									},
									"leftbtn" : {
										position:cc.p(0,16),
										size:cc.size(16,320),
										bg: cc.c4b(0,0,255,255),
										anchorPoint:cc.p(0,0),
										children:{
											"text":{
												label:"<",
												fontSize:12,
												anchorPoint:cc.p(0.5,0.5),
												position:cc.p(8,160),
												color:cc.c3b(255,255,255),
											}
										}
									},
									"rightbtn" : {
										position:cc.p(336,16),
										size:cc.size(16,320),
										bg: cc.c4b(0,0,255,255),
										anchorPoint:cc.p(0,0),
										children:{
											"text":{
												label:">",
												fontSize:12,
												anchorPoint:cc.p(0.5,0.5),
												position:cc.p(8,160),
												color:cc.c3b(255,255,255),
											}
										}
									},
									"upbtn" : {
										position:cc.p(16,336),
										size:cc.size(320,16),
										bg: cc.c4b(0,0,255,255),
										anchorPoint:cc.p(0,0),
										children:{
											"text":{
												label:"^",
												fontSize:12,
												anchorPoint:cc.p(0.5,0.5),
												position:cc.p(160,8),
												color:cc.c3b(255,255,255),
											}
										}
									},
									"downbtn" : {
										position:cc.p(16,0),
										size:cc.size(320,16),
										bg: cc.c4b(0,0,255,255),
										anchorPoint:cc.p(0,0),
										children:{
											"text":{
												label:"v",
												fontSize:12,
												anchorPoint:cc.p(0.5,0.5),
												position:cc.p(160,8),
												color:cc.c3b(255,255,255),
											}
										}
									},
									"fillbtn" : {
										position:cc.p(428,308),
										size:cc.size(60,32),
										bg: cc.c4b(255,255,255,255),
										anchorPoint:cc.p(0,0),
										children:{
											"text":{
												label:"Fill",
												fontSize:12,
												anchorPoint:cc.p(0.5,0.5),
												position:cc.p(32,16),
												color:cc.c3b(0,0,0),
											}
										}
									},
									"ground1btn" : {
										position:cc.p(360,278),
										size:cc.size(128,26),
										bg: cc.c4b(0,255,0,255),
										anchorPoint:cc.p(0,0),
										children:{
											"text":{
												label:"Ground 1",
												fontSize:12,
												anchorPoint:cc.p(0.5,0.5),
												position:cc.p(64,13),
												color:cc.c3b(0,0,0),
											}
										}
									},
									"ground2btn" : {
										position:cc.p(360,248),
										size:cc.size(128,26),
										bg: cc.c4b(255,255,255,255),
										anchorPoint:cc.p(0,0),
										children:{
											"text":{
												label:"Ground 2",
												fontSize:12,
												anchorPoint:cc.p(0.5,0.5),
												position:cc.p(64,13),
												color:cc.c3b(0,0,0),
											}
										}
									},
									"groundShadowbtn" : {
										position:cc.p(360,218),
										size:cc.size(128,26),
										bg: cc.c4b(255,255,255,255),
										anchorPoint:cc.p(0,0),
										children:{
											"text":{
												label:"Ground Shadow",
												fontSize:12,
												anchorPoint:cc.p(0.5,0.5),
												position:cc.p(64,13),
												color:cc.c3b(0,0,0),
											}
										}
									},
									"mask1btn" : {
										position:cc.p(360,188),
										size:cc.size(128,26),
										bg: cc.c4b(255,255,255,255),
										anchorPoint:cc.p(0,0),
										children:{
											"text":{
												label:"Mask 1",
												fontSize:12,
												anchorPoint:cc.p(0.5,0.5),
												position:cc.p(64,13),
												color:cc.c3b(0,0,0),
											}
										}
									},
									"mask2btn" : {
										position:cc.p(360,158),
										size:cc.size(128,26),
										bg: cc.c4b(255,255,255,255),
										anchorPoint:cc.p(0,0),
										children:{
											"text":{
												label:"Mask 2",
												fontSize:12,
												anchorPoint:cc.p(0.5,0.5),
												position:cc.p(64,13),
												color:cc.c3b(0,0,0),
											}
										}
									},
									"mask3btn" : {
										position:cc.p(360,128),
										size:cc.size(128,26),
										bg: cc.c4b(255,255,255,255),
										anchorPoint:cc.p(0,0),
										children:{
											"text":{
												label:"Mask 3",
												fontSize:12,
												anchorPoint:cc.p(0.5,0.5),
												position:cc.p(64,13),
												color:cc.c3b(0,0,0),
											}
										}
									},
									"fringe1btn" : {
										position:cc.p(360,98),
										size:cc.size(128,26),
										bg: cc.c4b(255,255,255,255),
										anchorPoint:cc.p(0,0),
										children:{
											"text":{
												label:"Fringe 1",
												fontSize:12,
												anchorPoint:cc.p(0.5,0.5),
												position:cc.p(64,13),
												color:cc.c3b(0,0,0),
											}
										}
									},
									"fringe2btn" : {
										position:cc.p(360,68),
										size:cc.size(128,26),
										bg: cc.c4b(255,255,255,255),
										anchorPoint:cc.p(0,0),
										children:{
											"text":{
												label:"Fringe 2",
												fontSize:12,
												anchorPoint:cc.p(0.5,0.5),
												position:cc.p(64,13),
												color:cc.c3b(0,0,0),
											}
										}
									},
									"fringeShadowbtn" : {
										position:cc.p(360,38),
										size:cc.size(128,26),
										bg: cc.c4b(255,255,255,255),
										anchorPoint:cc.p(0,0),
										children:{
											"text":{
												label:"Fringe Shadow",
												fontSize:12,
												anchorPoint:cc.p(0.5,0.5),
												position:cc.p(64,13),
												color:cc.c3b(0,0,0),
											}
										}
									},
									"fringe3btn" : {
										position:cc.p(360,8),
										size:cc.size(128,26),
										bg: cc.c4b(255,255,255,255),
										anchorPoint:cc.p(0,0),
										children:{
											"text":{
												label:"Fringe 3",
												fontSize:12,
												anchorPoint:cc.p(0.5,0.5),
												position:cc.p(64,13),
												color:cc.c3b(0,0,0),
											}
										}
									},
									
									"highlightnode" : {
										anchorPoint:cc.p(0,0),
										position:cc.p(0,0),
										size:cc.size(32,32),
										bg:cc.c4b(255,100,100,255),
									},
									"selectednode" : {
										anchorPoint:cc.p(0,0),
										position:cc.p(0,0),
										size:cc.size(32,32),
										bg:cc.c4b(100,255,100,255),
									},
								}
							},
							"tab2":{
								children:{
									"blockbtn" : {
										position:cc.p(8,320),
										size:cc.size(60,32),
										bg: cc.c4b(255,255,255,255),
										anchorPoint:cc.p(0,0),
										children:{
											"text":{
												label:"Block",
												fontSize:12,
												anchorPoint:cc.p(0.5,0.5),
												position:cc.p(32,16),
												color:cc.c3b(0,0,0),
											}
										}
									},
								}
							},
							"tab3":{
								children:{
									"saveBack":{
										position:cc.p(0,78),
										size:cc.size(200,60),
										bg: cc.c4b(0,255,0,100),
										anchorPoint:cc.p(0,0),
									},
									"deleteback":{
										position:cc.p(0,138),
										size:cc.size(200,60),
										bg: cc.c4b(255,0,0,100),
										anchorPoint:cc.p(0,0),
									},
									"mapnumsback":{
										position:cc.p(0,198),
										size:cc.size(200,162),
										bg: cc.c4b(0,0,0,170),
										anchorPoint:cc.p(0,0),
									},
									"mapUp_text":{
										label:"Map Up",
										fontSize:10,
										anchorPoint:cc.p(0.5,0),
										position: cc.p(100,344),
									},
									"mapUp_entry":{
										size: cc.size(60,32),
										position: cc.p(70,312),
									},
									"mapDown_text":{
										label:"Map Down",
										fontSize:10,
										anchorPoint:cc.p(0.5,0),
										position: cc.p(100,232),
									},
									"mapDown_entry":{
										size: cc.size(60,32),
										position: cc.p(70,200),
									},
									"mapLeft_text":{
										label:"Map Left",
										fontSize:10,
										anchorPoint:cc.p(0.5,0),
										position: cc.p(38,290),
									},
									"mapLeft_entry":{
										size: cc.size(60,32),
										position: cc.p(8,258),
									},
									"mapRight_text":{
										label:"Map Right",
										fontSize:10,
										anchorPoint:cc.p(0.5,0),
										position: cc.p(162,290),
									},
									"mapRight_entry":{
										size: cc.size(60,32),
										position: cc.p(132,258),
									},
									"this_map":{
										position:cc.p(70,248),
										size:cc.size(60,60),
										bg: cc.c4b(255,255,255,255),
										anchorPoint:cc.p(0,0),
										children:{
											"text":{
												label:"THIS MAP\n#"+ GameMap.getMapNumber(),
												fontSize:12,
												anchorPoint:cc.p(0.5,0.5),
												position:cc.p(30,30),
												color:cc.c3b(0,0,0),
											}
										}
									},
									"clearbtn" : {
										position:cc.p(70,150),
										size:cc.size(60,32),
										bg: cc.c4b(255,255,255,255),
										anchorPoint:cc.p(0,0),
										children:{
											"text":{
												label:"Clear",
												fontSize:12,
												anchorPoint:cc.p(0.5,0.5),
												position:cc.p(32,16),
												color:cc.c3b(0,0,0),
											}
										}
									},
									"clear_text":{
										label:"Clear Map: You sure?",
										fontSize:14,
										anchorPoint:cc.p(0.5,0),
										position: cc.p(100,182),
									},
									"clearbtnNo" : {
										position:cc.p(10,150),
										size:cc.size(60,32),
										bg: cc.c4b(255,255,255,255),
										anchorPoint:cc.p(0,0),
										children:{
											"text":{
												label:"NO",
												fontSize:12,
												anchorPoint:cc.p(0.5,0.5),
												position:cc.p(32,16),
												color:cc.c3b(0,0,0),
											}
										}
									},
									"clearbtnYes" : {
										position:cc.p(130,150),
										size:cc.size(60,32),
										bg: cc.c4b(255,255,255,255),
										anchorPoint:cc.p(0,0),
										children:{
											"text":{
												label:"YES",
												fontSize:12,
												anchorPoint:cc.p(0.5,0.5),
												position:cc.p(32,16),
												color:cc.c3b(0,0,0),
											}
										}
									},
									"savebtn" : {
										position:cc.p(70,90),
										size:cc.size(60,32),
										bg: cc.c4b(255,255,255,255),
										anchorPoint:cc.p(0,0),
										children:{
											"text":{
												label:"Save",
												fontSize:12,
												anchorPoint:cc.p(0.5,0.5),
												position:cc.p(32,16),
												color:cc.c3b(0,0,0),
											}
										}
									},
									"save_text":{
										label:"Save Map: You sure?",
										fontSize:14,
										anchorPoint:cc.p(0.5,0),
										position: cc.p(100,122),
									},
									"savebtnNo" : {
										position:cc.p(10,90),
										size:cc.size(60,32),
										bg: cc.c4b(255,255,255,255),
										anchorPoint:cc.p(0,0),
										children:{
											"text":{
												label:"NO",
												fontSize:12,
												anchorPoint:cc.p(0.5,0.5),
												position:cc.p(32,16),
												color:cc.c3b(0,0,0),
											}
										}
									},
									"savebtnYes" : {
										position:cc.p(130,90),
										size:cc.size(60,32),
										bg: cc.c4b(255,255,255,255),
										anchorPoint:cc.p(0,0),
										children:{
											"text":{
												label:"YES",
												fontSize:12,
												anchorPoint:cc.p(0.5,0.5),
												position:cc.p(32,16),
												color:cc.c3b(0,0,0),
											}
										}
									},
									"saveOnExit" : {
										position:cc.p(40,30),
										size:cc.size(120,32),
										bg: cc.c4b(255,255,255,255),
										anchorPoint:cc.p(0.5,0),
										children:{
											"content":{
												label:"",
												fontSize:14,
												anchorPoint:cc.p(0.5,0.5),
												position:cc.p(60,15),
												color:cc.c3b(0,0,0),
											}
										}
									},
								}
							},
							"tab1Clickable":{
								position:cc.p(0,360),
								size:cc.size(60,20),
								bg: cc.c4b(255,255,255,255),
								anchorPoint:cc.p(0,0),
								children:{
									"text":{
										label:"Editor",
										fontSize:12,
										anchorPoint:cc.p(0.5,0.5),
										position:cc.p(32,10),
										color:cc.c3b(0,0,0),
									}
								}
							},
							"tab2Clickable":{
								position:cc.p(64,360),
								size:cc.size(60,20),
								bg: cc.c4b(255,255,255,255),
								anchorPoint:cc.p(0,0),
								children:{
									"text":{
										label:"Scripts",
										fontSize:12,
										anchorPoint:cc.p(0.5,0.5),
										position:cc.p(32,10),
										color:cc.c3b(0,0,0),
									}
								}
							},
							"tab3Clickable":{
								position:cc.p(128,360),
								size:cc.size(60,20),
								bg: cc.c4b(255,255,255,255),
								anchorPoint:cc.p(0,0),
								children:{
									"text":{
										label:"Settings",
										fontSize:12,
										anchorPoint:cc.p(0.5,0.5),
										position:cc.p(32,10),
										color:cc.c3b(0,0,0),
									}
								}
							}
						}
					},
					"control_panel":{
						anchorPoint:cc.p(0,0),
						position: cc.p(0,380),
						size: cc.size(420,32),
						bg: cc.c4b(255,0,0,200),
						children:{	
							"header":{
								label:"Map Editor - Map #" + GameMap.getMapNumber(),
								fontSize:20,
								anchorPoint:cc.p(0,0.5),
								position:cc.p(8,16),
							}
						}
					},
				}
			}
		};
	},
	
	getIdentifier:function(){
		return "MapEditor";
	},
	mapOffset:null,
	mapUpBox:null,
	mapDownBox:null,
	mapLeftBox:null,
	mapRightBox:null,
	tabWidths:null,
	currentTab:0,
	
	init:function(_map){
		this._super();
		this.map =_map;
		this.mapOffset=cc.p(0,0);
		this.tabWidths=[null,496,200,200];
	},
	
	didBecomeActive:function(){
		this._super();
		this.panels["main_panel"]["tab1"]["highlightnode"].setOpacity(0);
		this.panels["main_panel"]["tab1"]["selectednode"].setOpacity(0);
		this.mapUpBox = new EntryBox(this.panels["main_panel"]["tab3"]["mapUp_entry"],cc.size(this.panels["main_panel"]["tab3"]["mapUp_entry"].getContentSize().width,this.panels["main_panel"]["tab3"]["mapUp_entry"].getContentSize().height), cc.p(0,this.panels["main_panel"]["tab3"]["mapUp_entry"].getContentSize().height), GameMap.hasMapUp() ? GameMap.getMapUp():"", cc.c4b(100,100,100), cc.c3b(255,255,255));
		this.mapUpBox.setDefaultFineFlag(true);
		this.mapUpBox.setNullAllowed(true);
		this.mapDownBox = new EntryBox(this.panels["main_panel"]["tab3"]["mapDown_entry"],cc.size(this.panels["main_panel"]["tab3"]["mapDown_entry"].getContentSize().width,this.panels["main_panel"]["tab3"]["mapDown_entry"].getContentSize().height), cc.p(0,this.panels["main_panel"]["tab3"]["mapDown_entry"].getContentSize().height), GameMap.hasMapDown() ? GameMap.getMapDown():"", cc.c4b(100,100,100), cc.c3b(255,255,255));
		this.mapDownBox.setDefaultFineFlag(true);
	    this.mapDownBox.setNullAllowed(true);
		this.mapLeftBox = new EntryBox(this.panels["main_panel"]["tab3"]["mapLeft_entry"],cc.size(this.panels["main_panel"]["tab3"]["mapLeft_entry"].getContentSize().width,this.panels["main_panel"]["tab3"]["mapLeft_entry"].getContentSize().height), cc.p(0,this.panels["main_panel"]["tab3"]["mapLeft_entry"].getContentSize().height), GameMap.hasMapLeft() ? GameMap.getMapLeft():"", cc.c4b(100,100,100), cc.c3b(255,255,255));
		this.mapLeftBox.setDefaultFineFlag(true);
		this.mapLeftBox.setNullAllowed(true);
		this.mapRightBox = new EntryBox(this.panels["main_panel"]["tab3"]["mapRight_entry"],cc.size(this.panels["main_panel"]["tab3"]["mapRight_entry"].getContentSize().width,this.panels["main_panel"]["tab3"]["mapRight_entry"].getContentSize().height), cc.p(0,this.panels["main_panel"]["tab3"]["mapRight_entry"].getContentSize().height), GameMap.hasMapRight() ? GameMap.getMapRight():"" , cc.c4b(100,100,100), cc.c3b(255,255,255));
		this.mapRightBox.setDefaultFineFlag(true);
		this.mapRightBox.setNullAllowed(true);
		this.showAreYouSureClear(false);
		this.showAreYouSureSave(false);
		this.saveOnExit=LocalStorage.getMapSaveOnExit();
		this.setSaveMapOnExit(this.saveOnExit);
		this.setTab(1);
		this.updateMapOffset();
		GameMap.setStringsVisible(true);
	},
	
	willTerminate:function(){
		if(this.saveOnExit==true){
			GameMap.setMapInfo({"up": this.mapUpBox.getText(),"down":this.mapDownBox.getText(),"left":this.mapLeftBox.getText(),"right":this.mapRightBox.getText()});
			GameMap.updateServer();
		}
		GameMap.setStringsVisible(false);
	},
	
	onMouseMoved:function(pos){
		if(this.currentTab==1){
			this.panels["main_panel"]["tab1"]["highlightnode"].setOpacity(0);
			var truePos = this.panels["main_panel"]["tab1"]["tiles"].convertToNodeSpace(pos);
			if(truePos.x>=0 && truePos.y>=0 && truePos.x<=this.panels["main_panel"]["tab1"]["tiles"].getContentSize().width && truePos.y<=this.panels["main_panel"]["tab1"]["tiles"].getContentSize().height){
				truePos.x = truePos.x-(truePos.x%32)+16;
				truePos.y = truePos.y-(truePos.y%32)+16;
				
				this.panels["main_panel"]["tab1"]["highlightnode"].setOpacity(127);
				this.panels["main_panel"]["tab1"]["highlightnode"].setPosition(truePos);
				return true;
			}
		}		
	},
	
	setTab:function(value){
		if(value!=this.currentTab){
			this.panels["main_panel"].setContentSize(this.tabWidths[value],this.panels["main_panel"].getContentSize().height);
			this.panels["control_panel"].setContentSize(this.tabWidths[value],this.panels["control_panel"].getContentSize().height);
			if(this.currentTab==3 || this.currentTab==0){
				this.panels["main_panel"]["tab3"]["mapUp_entry"].setPositionX(this.panels["main_panel"]["tab3"]["mapUp_entry"].getPositionX()-1000);
				this.panels["main_panel"]["tab3"]["mapLeft_entry"].setPositionX(this.panels["main_panel"]["tab3"]["mapLeft_entry"].getPositionX()-1000);
				this.panels["main_panel"]["tab3"]["mapDown_entry"].setPositionX(this.panels["main_panel"]["tab3"]["mapDown_entry"].getPositionX()-1000);
				this.panels["main_panel"]["tab3"]["mapRight_entry"].setPositionX(this.panels["main_panel"]["tab3"]["mapRight_entry"].getPositionX()-1000);
			}
			if(this.currentTab==1){
				if(this.editMode=="erasing" || this.editMode=="tiles"){
					this.editMode="blocking";
				}
			}
			if(this.currentTab==2){
				if(this.editMode=="blocking"){
					this.editMode="tiles";
				}
			}
			this.currentTab=value;
			this.panels["main_panel"]["tab1"].setVisible(false);
			this.panels["main_panel"]["tab2"].setVisible(false)
			this.panels["main_panel"]["tab3"].setVisible(false);
			this.panels["main_panel"]["tab1Clickable"].setColor(cc.c4b(255,255,255,255));
			this.panels["main_panel"]["tab2Clickable"].setColor(cc.c4b(255,255,255,255));
			this.panels["main_panel"]["tab3Clickable"].setColor(cc.c4b(255,255,255,255));
			this.panels["main_panel"]["tab"+value].setVisible(true);
			this.panels["main_panel"]["tab"+value+"Clickable"].setColor(cc.c4b(255,255,0,255));
			if(value==3){
				this.panels["main_panel"]["tab3"]["mapUp_entry"].setPositionX(this.panels["main_panel"]["tab3"]["mapUp_entry"].getPositionX()+1000);
				this.panels["main_panel"]["tab3"]["mapLeft_entry"].setPositionX(this.panels["main_panel"]["tab3"]["mapLeft_entry"].getPositionX()+1000);
				this.panels["main_panel"]["tab3"]["mapDown_entry"].setPositionX(this.panels["main_panel"]["tab3"]["mapDown_entry"].getPositionX()+1000);
				this.panels["main_panel"]["tab3"]["mapRight_entry"].setPositionX(this.panels["main_panel"]["tab3"]["mapRight_entry"].getPositionX()+1000);
			}
		}
	},
	
	setSaveMapOnExit:function(value){
		LocalStorage.setMapSaveOnExit(value);
		this.saveOnExit=value;
		if(value=="true" || value==true){
			this.panels["main_panel"]["tab3"]["saveOnExit"].setColor(cc.c3b(0,255,0));
			this.panels["main_panel"]["tab3"]["saveOnExit"]["content"].setString("Save on exit: YES");
		} else{
			this.panels["main_panel"]["tab3"]["saveOnExit"].setColor(cc.c3b(255,0,0));
			this.panels["main_panel"]["tab3"]["saveOnExit"]["content"].setString("Save on exit: NO");
		}
	},
	
	updateMapOffset:function(){
		if(this.panels["main_panel"]["tab1"]["tiles"].getTexture() && this.panels["main_panel"]["tab1"]["tiles"].getTexture()._isLoaded==true){
			this.unschedule(this.updateMapOffset);
			this.panels["main_panel"]["tab1"]["tiles"].setTextureRect(cc.rect(Math.floor(32*this.mapOffset.x),Math.floor(32*this.mapOffset.y),tileTextureList[this.currentTextureNumber]["texture"].getContentSize().width<320?tileTextureList[this.currentTextureNumber]["texture"].getContentSize().width:320,tileTextureList[this.currentTextureNumber]["texture"].getContentSize().height<320?tileTextureList[this.currentTextureNumber]["texture"].getContentSize().height:320));
		} else{
			this.schedule(this.updateMapOffset);
		}
	},
	
	onTouchBegan:function(touch){
		if(this._super(touch)){
			return true;
		}
		this.prevMovPos=null;
		var pos = touch._point;
		var truePos = this.panels["main_panel"].convertToNodeSpace(pos);

		if(cc.rectContainsPoint(cc.rect(this.panels["main_panel"]["tab1Clickable"].getPositionX(),this.panels["main_panel"]["tab1Clickable"].getPositionY(),this.panels["main_panel"]["tab1Clickable"].getContentSize().width,this.panels["main_panel"]["tab1Clickable"].getContentSize().height),truePos)){
			this.setTab(1);
			return true;
		}		
		
		if(cc.rectContainsPoint(cc.rect(this.panels["main_panel"]["tab2Clickable"].getPositionX(),this.panels["main_panel"]["tab2Clickable"].getPositionY(),this.panels["main_panel"]["tab2Clickable"].getContentSize().width,this.panels["main_panel"]["tab2Clickable"].getContentSize().height),truePos)){
			this.setTab(2);
			return true;
		}
	
		if(cc.rectContainsPoint(cc.rect(this.panels["main_panel"]["tab3Clickable"].getPositionX(),this.panels["main_panel"]["tab3Clickable"].getPositionY(),this.panels["main_panel"]["tab3Clickable"].getContentSize().width,this.panels["main_panel"]["tab3Clickable"].getContentSize().height),truePos)){
			this.setTab(3);
			return true;
		}
		
		if(this.currentTab==1){
			if(cc.rectContainsPoint(cc.rect(this.panels["main_panel"]["tab1"]["leftbtn"].getPositionX(),this.panels["main_panel"]["tab1"]["leftbtn"].getPositionY(),this.panels["main_panel"]["tab1"]["leftbtn"].getContentSize().width,this.panels["main_panel"]["tab1"]["leftbtn"].getContentSize().height),truePos)){
				if(tileTextureList[this.currentTextureNumber]["texture"].getContentSize().width>320 && this.mapOffset.x>0){
					this.mapOffset.x--;
					this.updateMapOffset();
				}
				return true;
			}
			if(cc.rectContainsPoint(cc.rect(this.panels["main_panel"]["tab1"]["rightbtn"].getPositionX(),this.panels["main_panel"]["tab1"]["rightbtn"].getPositionY(),this.panels["main_panel"]["tab1"]["rightbtn"].getContentSize().width,this.panels["main_panel"]["tab1"]["rightbtn"].getContentSize().height),truePos)){
				if(tileTextureList[this.currentTextureNumber]["texture"].getContentSize().width>320 && this.mapOffset.x<((tileTextureList[this.currentTextureNumber]["texture"].getContentSize().width-320)/32)){
					this.mapOffset.x++;
					this.updateMapOffset();
				}
				return true;
			}
			if(cc.rectContainsPoint(cc.rect(this.panels["main_panel"]["tab1"]["upbtn"].getPositionX(),this.panels["main_panel"]["tab1"]["upbtn"].getPositionY(),this.panels["main_panel"]["tab1"]["upbtn"].getContentSize().width,this.panels["main_panel"]["tab1"]["upbtn"].getContentSize().height),truePos)){
				if(tileTextureList[this.currentTextureNumber]["texture"].getContentSize().height>320 && this.mapOffset.y>0){
					this.mapOffset.y--;
					this.updateMapOffset();
				}
				return true;
			}
			if(cc.rectContainsPoint(cc.rect(this.panels["main_panel"]["tab1"]["downbtn"].getPositionX(),this.panels["main_panel"]["tab1"]["downbtn"].getPositionY(),this.panels["main_panel"]["tab1"]["downbtn"].getContentSize().width,this.panels["main_panel"]["tab1"]["downbtn"].getContentSize().height),truePos)){
				if(tileTextureList[this.currentTextureNumber]["texture"].getContentSize().height>320 && this.mapOffset.y<((tileTextureList[this.currentTextureNumber]["texture"].getContentSize().height-320)/32)){
					this.mapOffset.y++;
					this.updateMapOffset();
				}
				return true;
			}
			if(cc.rectContainsPoint(cc.rect(this.panels["main_panel"]["tab1"]["ground1btn"].getPositionX(),this.panels["main_panel"]["tab1"]["ground1btn"].getPositionY(),this.panels["main_panel"]["tab1"]["ground1btn"].getContentSize().width,this.panels["main_panel"]["tab1"]["ground1btn"].getContentSize().height),truePos)){
				this.updateCurrentLayer("ground1");
				return true;
			}
			if(cc.rectContainsPoint(cc.rect(this.panels["main_panel"]["tab1"]["ground2btn"].getPositionX(),this.panels["main_panel"]["tab1"]["ground2btn"].getPositionY(),this.panels["main_panel"]["tab1"]["ground2btn"].getContentSize().width,this.panels["main_panel"]["tab1"]["ground2btn"].getContentSize().height),truePos)){
				this.updateCurrentLayer("ground2");
				return true;
			}
			if(cc.rectContainsPoint(cc.rect(this.panels["main_panel"]["tab1"]["groundShadowbtn"].getPositionX(),this.panels["main_panel"]["tab1"]["groundShadowbtn"].getPositionY(),this.panels["main_panel"]["tab1"]["groundShadowbtn"].getContentSize().width,this.panels["main_panel"]["tab1"]["groundShadowbtn"].getContentSize().height),truePos)){
				this.updateCurrentLayer("groundShadow");
				return true;
			}
			if(cc.rectContainsPoint(cc.rect(this.panels["main_panel"]["tab1"]["mask1btn"].getPositionX(),this.panels["main_panel"]["tab1"]["mask1btn"].getPositionY(),this.panels["main_panel"]["tab1"]["mask1btn"].getContentSize().width,this.panels["main_panel"]["tab1"]["mask1btn"].getContentSize().height),truePos)){
				this.updateCurrentLayer("mask1");
				return true;
			}
			if(cc.rectContainsPoint(cc.rect(this.panels["main_panel"]["tab1"]["mask2btn"].getPositionX(),this.panels["main_panel"]["tab1"]["mask2btn"].getPositionY(),this.panels["main_panel"]["tab1"]["mask2btn"].getContentSize().width,this.panels["main_panel"]["tab1"]["mask2btn"].getContentSize().height),truePos)){
				this.updateCurrentLayer("mask2");
				return true;
			}
			if(cc.rectContainsPoint(cc.rect(this.panels["main_panel"]["tab1"]["mask3btn"].getPositionX(),this.panels["main_panel"]["tab1"]["mask3btn"].getPositionY(),this.panels["main_panel"]["tab1"]["mask3btn"].getContentSize().width,this.panels["main_panel"]["tab1"]["mask3btn"].getContentSize().height),truePos)){
				this.updateCurrentLayer("mask3");
				return true;
			}
			if(cc.rectContainsPoint(cc.rect(this.panels["main_panel"]["tab1"]["fringe1btn"].getPositionX(),this.panels["main_panel"]["tab1"]["fringe1btn"].getPositionY(),this.panels["main_panel"]["tab1"]["fringe1btn"].getContentSize().width,this.panels["main_panel"]["tab1"]["fringe1btn"].getContentSize().height),truePos)){
				this.updateCurrentLayer("fringe1");
				return true;
			}
			if(cc.rectContainsPoint(cc.rect(this.panels["main_panel"]["tab1"]["fringe2btn"].getPositionX(),this.panels["main_panel"]["tab1"]["fringe2btn"].getPositionY(),this.panels["main_panel"]["tab1"]["fringe2btn"].getContentSize().width,this.panels["main_panel"]["tab1"]["fringe2btn"].getContentSize().height),truePos)){
				this.updateCurrentLayer("fringe2");
				return true;
			}
			if(cc.rectContainsPoint(cc.rect(this.panels["main_panel"]["tab1"]["fringeShadowbtn"].getPositionX(),this.panels["main_panel"]["tab1"]["fringeShadowbtn"].getPositionY(),this.panels["main_panel"]["tab1"]["fringeShadowbtn"].getContentSize().width,this.panels["main_panel"]["tab1"]["fringeShadowbtn"].getContentSize().height),truePos)){
				this.updateCurrentLayer("fringeShadow");
				return true;
			}
			if(cc.rectContainsPoint(cc.rect(this.panels["main_panel"]["tab1"]["fringe3btn"].getPositionX(),this.panels["main_panel"]["tab1"]["fringe3btn"].getPositionY(),this.panels["main_panel"]["tab1"]["fringe3btn"].getContentSize().width,this.panels["main_panel"]["tab1"]["fringe3btn"].getContentSize().height),truePos)){
				this.updateCurrentLayer("fringe3");
				return true;
			}
			if(cc.rectContainsPoint(cc.rect(this.panels["main_panel"]["tab1"]["texturerightbtn"].getPositionX(),this.panels["main_panel"]["tab1"]["texturerightbtn"].getPositionY(),this.panels["main_panel"]["tab1"]["texturerightbtn"].getContentSize().width,this.panels["main_panel"]["tab1"]["texturerightbtn"].getContentSize().height),truePos)){
				this.useNextTexture();
				return true;
			}
			if(cc.rectContainsPoint(cc.rect(this.panels["main_panel"]["tab1"]["textureleftbtn"].getPositionX(),this.panels["main_panel"]["tab1"]["textureleftbtn"].getPositionY(),this.panels["main_panel"]["tab1"]["textureleftbtn"].getContentSize().width,this.panels["main_panel"]["tab1"]["textureleftbtn"].getContentSize().height),truePos)){
				this.usePrevTexture();
				return true;
			}
			SceneManager.setActiveScene(this);
			truePos = this.panels["main_panel"]["tab1"]["tiles"].convertToNodeSpace(pos);
			if(truePos.x>=0 && truePos.y>=0 && truePos.x<=this.panels["main_panel"]["tab1"]["tiles"].getContentSize().width && truePos.y<=this.panels["main_panel"]["tab1"]["tiles"].getContentSize().height){
				truePos.x = truePos.x-(truePos.x%32)+16;
				truePos.y = truePos.y-(truePos.y%32)+16;
				
				if(this.panels["main_panel"]["tab1"]["selectednode"].getPositionX()!=truePos.x || this.panels["main_panel"]["tab1"]["selectednode"].getPositionY()!=truePos.y){
					this.panels["main_panel"]["tab1"]["selectednode"].setOpacity(127);
					this.panels["main_panel"]["tab1"]["selectednode"].setPosition(truePos);
				} else{
					this.panels["main_panel"]["tab1"]["selectednode"].setOpacity(0);
				}
				return true;
			} 
			
			var globalErasePos = this.panels["main_panel"]["tab1"]["deletebtn"].convertToWorldSpace(cc.p(0,0));
			if(cc.rectContainsPoint(cc.rect(globalErasePos.x,globalErasePos.y,this.panels["main_panel"]["tab1"]["deletebtn"].getContentSize().width,this.panels["main_panel"]["tab1"]["deletebtn"].getContentSize().height),touch._point)){
				this.editMode=this.editMode=="erasing" ? "tiles" : "erasing";
				if(this.editMode=="erasing"){
					this.panels["main_panel"]["tab1"]["fillbtn"].setColor(cc.c4b(255,255,255,255));
					this.panels["main_panel"]["tab1"]["deletebtn"].setColor(cc.c4b(255,0,0,255));
				} else{
					this.panels["main_panel"]["tab1"]["deletebtn"].setColor(cc.c4b(255,255,255,255));
				}
				return true;
			}
			
			var globalFillPos = this.panels["main_panel"]["tab1"]["fillbtn"].convertToWorldSpace(cc.p(0,0));
			if(cc.rectContainsPoint(cc.rect(globalFillPos.x,globalFillPos.y,this.panels["main_panel"]["tab1"]["fillbtn"].getContentSize().width,this.panels["main_panel"]["tab1"]["fillbtn"].getContentSize().height),touch._point)){
				if(this.panels["main_panel"]["tab1"]["selectednode"].getOpacity()!=0){
					GameMap.fillMap(tileTextureList[this.currentTextureNumber]["name"],cc.p(((this.panels["main_panel"]["tab1"]["selectednode"].getPositionX()-16)/32)+this.mapOffset.x,(9-((this.panels["main_panel"]["tab1"]["selectednode"].getPositionY()-16)/32))+this.mapOffset.y),this.currentLayer);
					GameMap.updateMap();
				}
				return true;
			}
		}
		if(this.currentTab==2){			
			var globalBlockPos = this.panels["main_panel"]["tab2"]["blockbtn"].convertToWorldSpace(cc.p(0,0));
			if(cc.rectContainsPoint(cc.rect(globalBlockPos.x,globalBlockPos.y,this.panels["main_panel"]["tab2"]["blockbtn"].getContentSize().width,this.panels["main_panel"]["tab2"]["blockbtn"].getContentSize().height),touch._point)){
				this.editMode = this.editMode=="blocking" ? "tiles" : "blocking";
				if(this.editMode=="blocking"){
					this.panels["main_panel"]["tab2"]["blockbtn"].setColor(cc.c4b(255,0,0,255));
				} else{
					this.panels["main_panel"]["tab2"]["blockbtn"].setColor(cc.c4b(255,255,255,255));
				}
				return true;
			}
		}
		
		if(this.currentTab==3){
			var globalClearPos = this.panels["main_panel"]["tab3"]["clearbtn"].convertToWorldSpace(cc.p(0,0));
			if(this.panels["main_panel"]["tab3"]["clearbtn"].isVisible() && cc.rectContainsPoint(cc.rect(globalClearPos.x,globalClearPos.y,this.panels["main_panel"]["tab3"]["clearbtn"].getContentSize().width,this.panels["main_panel"]["tab3"]["clearbtn"].getContentSize().height),touch._point)){
				this.showAreYouSureClear(true);
				return true;
			}
			var globalClearPos = this.panels["main_panel"]["tab3"]["clearbtnNo"].convertToWorldSpace(cc.p(0,0));
			if(this.panels["main_panel"]["tab3"]["clearbtnNo"].isVisible() && cc.rectContainsPoint(cc.rect(globalClearPos.x,globalClearPos.y,this.panels["main_panel"]["tab3"]["clearbtnNo"].getContentSize().width,this.panels["main_panel"]["tab3"]["clearbtnNo"].getContentSize().height),touch._point)){
				console.log("Closin");
				this.showAreYouSureClear(false);
				return true;
			}
			var globalClearPos = this.panels["main_panel"]["tab3"]["clearbtnYes"].convertToWorldSpace(cc.p(0,0));
			if(this.panels["main_panel"]["tab3"]["clearbtnYes"].isVisible() && cc.rectContainsPoint(cc.rect(globalClearPos.x,globalClearPos.y,this.panels["main_panel"]["tab3"]["clearbtnYes"].getContentSize().width,this.panels["main_panel"]["tab3"]["clearbtnYes"].getContentSize().height),touch._point)){
				GameMap.destroy();
				this.showAreYouSureClear(false);
				return true;
			}
			var globalSavePos = this.panels["main_panel"]["tab3"]["savebtn"].convertToWorldSpace(cc.p(0,0));
			if(this.panels["main_panel"]["tab3"]["savebtn"].isVisible() && cc.rectContainsPoint(cc.rect(globalSavePos.x,globalSavePos.y,this.panels["main_panel"]["tab3"]["savebtn"].getContentSize().width,this.panels["main_panel"]["tab3"]["savebtn"].getContentSize().height),touch._point)){
				this.showAreYouSureSave(true);
				return true;
			}
			var globalSavePos = this.panels["main_panel"]["tab3"]["savebtnNo"].convertToWorldSpace(cc.p(0,0));
			if(this.panels["main_panel"]["tab3"]["savebtnNo"].isVisible() && cc.rectContainsPoint(cc.rect(globalSavePos.x,globalSavePos.y,this.panels["main_panel"]["tab3"]["savebtnNo"].getContentSize().width,this.panels["main_panel"]["tab3"]["savebtnNo"].getContentSize().height),touch._point)){
				console.log("Closin");
				this.showAreYouSureSave(false);
				return true;
			}
			var globalSavePos = this.panels["main_panel"]["tab3"]["savebtnYes"].convertToWorldSpace(cc.p(0,0));
			if(this.panels["main_panel"]["tab3"]["savebtnYes"].isVisible() && cc.rectContainsPoint(cc.rect(globalSavePos.x,globalSavePos.y,this.panels["main_panel"]["tab3"]["savebtnYes"].getContentSize().width,this.panels["main_panel"]["tab3"]["savebtnYes"].getContentSize().height),touch._point)){
				GameMap.setMapInfo({"up": this.mapUpBox.getText(),"down":this.mapDownBox.getText(),"left":this.mapLeftBox.getText(),"right":this.mapRightBox.getText()});
				GameMap.updateServer();
				this.showAreYouSureSave(false);
				return true;
			}
			
			var globalSavePos = this.panels["main_panel"]["tab3"]["saveOnExit"].convertToWorldSpace(cc.p(0,0));
			if(this.panels["main_panel"]["tab3"]["saveOnExit"].isVisible() && cc.rectContainsPoint(cc.rect(globalSavePos.x,globalSavePos.y,this.panels["main_panel"]["tab3"]["saveOnExit"].getContentSize().width,this.panels["main_panel"]["tab3"]["saveOnExit"].getContentSize().height),touch._point)){
				this.setSaveMapOnExit(!this.saveOnExit);
				return true;
			}
			
		}
		
		return false;
	},	
	
	updateCurrentLayer:function(layerName){
		this.panels["main_panel"]["tab1"]["ground1btn"].setColor(cc.c4b(255,255,255,255));
		this.panels["main_panel"]["tab1"]["ground2btn"].setColor(cc.c4b(255,255,255,255));
		this.panels["main_panel"]["tab1"]["groundShadowbtn"].setColor(cc.c4b(255,255,255,255));
		this.panels["main_panel"]["tab1"]["mask1btn"].setColor(cc.c4b(255,255,255,255));
		this.panels["main_panel"]["tab1"]["mask2btn"].setColor(cc.c4b(255,255,255,255));
		this.panels["main_panel"]["tab1"]["mask3btn"].setColor(cc.c4b(255,255,255,255));
		this.panels["main_panel"]["tab1"]["fringe1btn"].setColor(cc.c4b(255,255,255,255));
		this.panels["main_panel"]["tab1"]["fringe2btn"].setColor(cc.c4b(255,255,255,255));
		this.panels["main_panel"]["tab1"]["fringeShadowbtn"].setColor(cc.c4b(255,255,255,255));
		this.panels["main_panel"]["tab1"]["fringe3btn"].setColor(cc.c4b(255,255,255,255));
		this.panels["main_panel"]["tab1"][layerName+"btn"].setColor(cc.c4b(0,255,0,255));
		this.currentLayer=layerName;
	},
	
	useNextTexture:function(){
		if(this.currentTextureNumber>=tileTextureList.length-1){
			this.currentTextureNumber=-1;
		}
		this.currentTextureNumber++;
		this.panels["main_panel"]["tab1"]["tiles"].setTexture(tileTextureList[this.currentTextureNumber]["texture"]);
		this.currentTexture = tileTextureList[this.currentTextureNumber]["name"];
		this.panels["main_panel"]["tab1"]["textureName"]["text"].setString(this.currentTexture);
		this.mapOffset=cc.p(0,0);
		this.updateMapOffset();
	},
	
	usePrevTexture:function(){
		if(this.currentTextureNumber<=0){
			this.currentTextureNumber=tileTextureList.length;
		}
		this.currentTextureNumber--;
		this.panels["main_panel"]["tab1"]["tiles"].setTexture(tileTextureList[this.currentTextureNumber]["texture"]);
		this.currentTexture = tileTextureList[this.currentTextureNumber]["name"];
		this.panels["main_panel"]["tab1"]["textureName"]["text"].setString(this.currentTexture);
		this.mapOffset=cc.p(0,0);
		this.updateMapOffset();
	},
	
	showAreYouSureClear:function(visible){
		this.panels["main_panel"]["tab3"]["clearbtnYes"].setVisible(visible);
		this.panels["main_panel"]["tab3"]["clearbtnNo"].setVisible(visible);	
		this.panels["main_panel"]["tab3"]["clear_text"].setVisible(visible);	
		this.panels["main_panel"]["tab3"]["clearbtn"].setVisible(!visible);
	},
	
	showAreYouSureSave:function(visible){
		this.panels["main_panel"]["tab3"]["savebtnYes"].setVisible(visible);
		this.panels["main_panel"]["tab3"]["savebtnNo"].setVisible(visible);	
		this.panels["main_panel"]["tab3"]["save_text"].setVisible(visible);	
		this.panels["main_panel"]["tab3"]["savebtn"].setVisible(!visible);
	},
	
	tilePressed:function(tiles,tilenum,touchtype){
		if(tiles[tilenum]==this.lastTile && touchtype=="moved"){
			return false;
		}
		this.lastTile=tiles[tilenum];
		switch(this.editMode){
			case "tiles":
				if(this.panels["main_panel"]["tab1"]["selectednode"].getOpacity()!=0){
					GameMap.setLayer(tilenum,tileTextureList[this.currentTextureNumber]["name"],cc.p(((this.panels["main_panel"]["tab1"]["selectednode"].getPositionX()-16)/32)+this.mapOffset.x,(9-((this.panels["main_panel"]["tab1"]["selectednode"].getPositionY()-16)/32))+this.mapOffset.y),this.currentLayer);
				}
			break;
			case "blocking":
				if(tiles[tilenum].getType()!=1){
					GameMap.setTileInfo(tilenum,1);
				} else{
					GameMap.setTileInfo(tilenum,0);
				}
			break;
			case "erasing":
				GameMap.destroyLayer(tilenum,this.currentLayer);
			break;
		}
		
	}
});


ItemEditor = Popup.extend({
	
	getLayoutObject:function(){
		return { "panels":{
				position:cc.p(300,10),
				children:{	
					"main_panel":{
						anchorPoint:cc.p(0,0),
						position: cc.p(0,0),
						size: cc.size(420,352),
						bg: cc.c4b(0,0,100,120),
						children: {
							"items" : {
								anchorPoint:cc.p(0,1),
								position:cc.p(16,336),
								texture:"items1.png",
							},
							"deletebtn" : {
								position:cc.p(356,316),
								size:cc.size(60,32),
								bg: cc.c4b(255,255,255,255),
								anchorPoint:cc.p(0,0),
								children:{
									"text":{
										label:"Erase",
										fontSize:12,
										anchorPoint:cc.p(0.5,0.5),
										position:cc.p(32,16),
										color:cc.c3b(0,0,0),
									}
								}
							},
							"leftbtn" : {
								position:cc.p(0,16),
								size:cc.size(16,320),
								bg: cc.c4b(0,0,255,255),
								anchorPoint:cc.p(0,0),
								children:{
									"text":{
										label:"<",
										fontSize:12,
										anchorPoint:cc.p(0.5,0.5),
										position:cc.p(8,160),
										color:cc.c3b(255,255,255),
									}
								}
							},
							"rightbtn" : {
								position:cc.p(336,16),
								size:cc.size(16,320),
								bg: cc.c4b(0,0,255,255),
								anchorPoint:cc.p(0,0),
								children:{
									"text":{
										label:">",
										fontSize:12,
										anchorPoint:cc.p(0.5,0.5),
										position:cc.p(8,160),
										color:cc.c3b(255,255,255),
									}
								}
							},
							"upbtn" : {
								position:cc.p(16,336),
								size:cc.size(320,16),
								bg: cc.c4b(0,0,255,255),
								anchorPoint:cc.p(0,0),
								children:{
									"text":{
										label:"^",
										fontSize:12,
										anchorPoint:cc.p(0.5,0.5),
										position:cc.p(160,8),
										color:cc.c3b(255,255,255),
									}
								}
							},
							"downbtn" : {
								position:cc.p(16,0),
								size:cc.size(320,16),
								bg: cc.c4b(0,0,255,255),
								anchorPoint:cc.p(0,0),
								children:{
									"text":{
										label:"v",
										fontSize:12,
										anchorPoint:cc.p(0.5,0.5),
										position:cc.p(160,8),
										color:cc.c3b(255,255,255),
									}
								}
							},
							"highlightnode" : {
								anchorPoint:cc.p(0,0),
								position:cc.p(0,0),
								size:cc.size(32,32),
								bg:cc.c4b(255,100,100,255),
							},
							"selectednode" : {
								anchorPoint:cc.p(0,0),
								position:cc.p(0,0),
								size:cc.size(32,32),
								bg:cc.c4b(100,255,100,255),
							}
						}
					},
					"control_panel":{
						anchorPoint:cc.p(0,0),
						position: cc.p(0,352),
						size: cc.size(420,32),
						bg: cc.c4b(255,0,0,200),
						children:{	
							"header":{
								label:"Item Editor",
								fontSize:20,
								anchorPoint:cc.p(0,0.5),
								position:cc.p(8,16),
							}
						}
					},
				}
			}
		};

	},
	
	getIdentifier:function(){
		return "ItemEditor";
	},
	mapOffset:null,
	
	init:function(_map){
		this._super();
		this.map =_map;
		this.mapOffset=cc.p(0,0);
	},
	
	didBecomeActive:function(){
		this._super();
		this.panels["main_panel"]["highlightnode"].setOpacity(0);
		this.panels["main_panel"]["selectednode"].setOpacity(0);
		this.updateMapOffset();
	},
	
	willTerminate:function(){
		GameMap.updateServer();
		GameMap.setStringsVisible(false);
	},
	
	onMouseMoved:function(pos){
		this.panels["main_panel"]["highlightnode"].setOpacity(0);
		var truePos = this.panels["main_panel"]["items"].convertToNodeSpace(pos);
		if(truePos.x>=0 && truePos.y>=0 && truePos.x<=this.panels["main_panel"]["items"].getContentSize().width && truePos.y<=this.panels["main_panel"]["items"].getContentSize().height){
			truePos.x = truePos.x-(truePos.x%32)+16;
			truePos.y = truePos.y-(truePos.y%32)+16;
			
			this.panels["main_panel"]["highlightnode"].setOpacity(127);
			this.panels["main_panel"]["highlightnode"].setPosition(truePos);
			return true;
		} 
	},
	
	updateMapOffset:function(){
		if(this.panels["main_panel"]["items"].getTexture() && this.panels["main_panel"]["items"].getTexture()._isLoaded==true){
			this.unschedule(this.updateMapOffset);
			this.panels["main_panel"]["items"].setTextureRect(cc.rect(Math.floor(32*this.mapOffset.x),Math.floor(32*this.mapOffset.y),this.panels["main_panel"]["items"].getContentSize().width<320?this.panels["main_panel"]["items"].getContentSize().width:320,this.panels["main_panel"]["items"].getContentSize().height<320?this.panels["main_panel"]["items"].getContentSize().height:320));
		} else{
			this.schedule(this.updateMapOffset);
		}
	},
	
	
	onTouchBegan:function(touch){
		if(this._super(touch)){
			return true;
		}
		this.prevMovPos=null;
		var pos = touch._point;
		var truePos = this.panels["main_panel"].convertToNodeSpace(pos);
		if(cc.rectContainsPoint(cc.rect(this.panels["main_panel"]["leftbtn"].getPositionX(),this.panels["main_panel"]["leftbtn"].getPositionY(),this.panels["main_panel"]["leftbtn"].getContentSize().width,this.panels["main_panel"]["leftbtn"].getContentSize().height),truePos)){
			this.mapOffset.x--;
			this.updateMapOffset();
			cc.log("UPDATE");
			return true;
		}
		if(cc.rectContainsPoint(cc.rect(this.panels["main_panel"]["rightbtn"].getPositionX(),this.panels["main_panel"]["rightbtn"].getPositionY(),this.panels["main_panel"]["rightbtn"].getContentSize().width,this.panels["main_panel"]["rightbtn"].getContentSize().height),truePos)){
			this.mapOffset.x++;
			this.updateMapOffset();
			return true;
		}
		if(cc.rectContainsPoint(cc.rect(this.panels["main_panel"]["upbtn"].getPositionX(),this.panels["main_panel"]["upbtn"].getPositionY(),this.panels["main_panel"]["upbtn"].getContentSize().width,this.panels["main_panel"]["upbtn"].getContentSize().height),truePos)){
			this.mapOffset.y--;
			this.updateMapOffset();
			return true;
		}
		if(cc.rectContainsPoint(cc.rect(this.panels["main_panel"]["downbtn"].getPositionX(),this.panels["main_panel"]["downbtn"].getPositionY(),this.panels["main_panel"]["downbtn"].getContentSize().width,this.panels["main_panel"]["downbtn"].getContentSize().height),truePos)){
			this.mapOffset.y++;
			this.updateMapOffset();
			return true;
		}
		SceneManager.setActiveScene(this);
		truePos = this.panels["main_panel"]["tiles"].convertToNodeSpace(pos);
		if(truePos.x>=0 && truePos.y>=0 && truePos.x<=this.panels["main_panel"]["tiles"].getContentSize().width && truePos.y<=this.panels["main_panel"]["tiles"].getContentSize().height){
			truePos.x = truePos.x-(truePos.x%32)+16;
			truePos.y = truePos.y-(truePos.y%32)+16;
			
			if(this.panels["main_panel"]["selectednode"].getPositionX()!=truePos.x || this.panels["main_panel"]["selectednode"].getPositionY()!=truePos.y){
				this.panels["main_panel"]["selectednode"].setOpacity(127);
				this.panels["main_panel"]["selectednode"].setPosition(truePos);
			} else{
				this.panels["main_panel"]["selectednode"].setOpacity(0);
			}
			return true;
		} 
		
		var globalErasePos = this.panels["main_panel"]["deletebtn"].convertToWorldSpace(cc.p(0,0));
		if(cc.rectContainsPoint(cc.rect(globalErasePos.x,globalErasePos.y,this.panels["main_panel"]["deletebtn"].getContentSize().width,this.panels["main_panel"]["deletebtn"].getContentSize().height),touch._point)){
			this.editMode=this.editMode=="erasing" ? "tiles" : "erasing";
			if(this.editMode=="erasing"){
				this.panels["main_panel"]["blockbtn"].setColor(cc.c4b(255,255,255,255));
				this.panels["main_panel"]["fillbtn"].setColor(cc.c4b(255,255,255,255));
				this.panels["main_panel"]["deletebtn"].setColor(cc.c4b(255,0,0,255));
			} else{
				this.panels["main_panel"]["deletebtn"].setColor(cc.c4b(255,255,255,255));
			}
			return true;
		}
		var globalBlockPos = this.panels["main_panel"]["blockbtn"].convertToWorldSpace(cc.p(0,0));
		if(cc.rectContainsPoint(cc.rect(globalBlockPos.x,globalBlockPos.y,this.panels["main_panel"]["blockbtn"].getContentSize().width,this.panels["main_panel"]["blockbtn"].getContentSize().height),touch._point)){
			this.editMode = this.editMode=="blocking" ? "tiles" : "blocking";
			if(this.editMode=="blocking"){
				this.panels["main_panel"]["deletebtn"].setColor(cc.c4b(255,255,255,255));
				this.panels["main_panel"]["fillbtn"].setColor(cc.c4b(255,255,255,255));
				this.panels["main_panel"]["blockbtn"].setColor(cc.c4b(255,0,0,255));
			} else{
				this.panels["main_panel"]["blockbtn"].setColor(cc.c4b(255,255,255,255));
			}
			return true;
		}
		var globalFillPos = this.panels["main_panel"]["fillbtn"].convertToWorldSpace(cc.p(0,0));
		if(cc.rectContainsPoint(cc.rect(globalFillPos.x,globalFillPos.y,this.panels["main_panel"]["fillbtn"].getContentSize().width,this.panels["main_panel"]["fillbtn"].getContentSize().height),touch._point)){
			this.editMode = this.editMode=="filling" ? "tiles" : "filling";
			if(this.editMode=="filling"){
				this.panels["main_panel"]["deletebtn"].setColor(cc.c4b(255,255,255,255));
				this.panels["main_panel"]["blockbtn"].setColor(cc.c4b(255,255,255,255));
				this.panels["main_panel"]["fillbtn"].setColor(cc.c4b(255,0,0,255));
			} else{
				this.panels["main_panel"]["fillbtn"].setColor(cc.c4b(255,255,255,255));
			}
			return true;
		}
		var globalClearPos = this.panels["main_panel"]["clearbtn"].convertToWorldSpace(cc.p(0,0));
		if(cc.rectContainsPoint(cc.rect(globalClearPos.x,globalClearPos.y,this.panels["main_panel"]["clearbtn"].getContentSize().width,this.panels["main_panel"]["clearbtn"].getContentSize().height),touch._point)){
			GameMap.destroy();
		}
		
		
		/*var globalErasePos = this.panels["main_panel"]["deletebtn"].convertToWorldSpace(cc.p(0,0));
		if(cc.rectContainsPoint(cc.rect(globalErasePos.x,globalErasePos.y,this.panels["main_panel"]["deletebtn"].getContentSize().width,this.panels["main_panel"]["deletebtn"].getContentSize().height),touch._point)){
			this.isDelete=!this.isDelete;
			if(this.isDelete){
				this.panels["main_panel"]["deletebtn"].setColor(cc.c4b(255,0,0,255));
			} else{
				this.panels["main_panel"]["deletebtn"].setColor(cc.c4b(255,255,255,255));
			}
			return true;
		}*/
		return false;
	},	
	
	tilePressed:function(tile,tilenum,touchtype){
		if(this.editMode=="filling" && touchtype=="moved"){
			return false;
		}
		if(tile==this.lastTile && touchtype=="moved"){
			return false;
		}
		this.lastTile=tile;
		switch(this.editMode){
			case "tiles":
				if(this.panels["main_panel"]["selectednode"].getOpacity()!=0){
					GameMap.pushLayer(tilenum,tileTextureList[this.currentTextureNumber]["name"],cc.p(((this.panels["main_panel"]["selectednode"].getPositionX()-16)/32)+this.mapOffset.x,(9-((this.panels["main_panel"]["selectednode"].getPositionY()-16)/32))+this.mapOffset.y),this.currentLayer);
				}
			break;
			case "blocking":
				if(tile.getType()!=1){
					GameMap.setTileInfo(tilenum,1);
				} else{
					GameMap.setTileInfo(tilenum,0);
				}
			break;
			case "erasing":
				GameMap.popLayer(tilenum);
			break;
			case "filling":
				if(this.panels["main_panel"]["selectednode"].getOpacity()!=0){
					GameMap.fillMap(tileTextureList[this.currentTextureNumber]["name"],cc.p(((this.panels["main_panel"]["selectednode"].getPositionX()-16)/32)+this.mapOffset.x,(9-((this.panels["main_panel"]["selectednode"].getPositionY()-16)/32))+this.mapOffset.y),this.currentLayer);
				}
			break;
		}
		
	}
});



