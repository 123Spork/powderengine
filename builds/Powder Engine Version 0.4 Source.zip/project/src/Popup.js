Popup = Scene.extend({
	prevMovPos:null,

	init:function(){
		this.sceneIdentifier = this.getIdentifier();
		this._super();	
		SceneManager.setActiveScene(this);
		this.setupPopup();
	},

	exitButtonPressed:function(){
		this.removeFromParent();
	},

	onTouchBegan:function(touch){
		if(cc.rectContainsPoint(cc.rect(this.panels.getPosition().x,this.panels.getPosition().y+this.panels["control_panel"].getPosition().y,this.panels["control_panel"].getContentSize().width,this.panels["control_panel"].getContentSize().height),touch._point)){
			this.prevMovPos=this.panels.convertTouchToNodeSpace(touch);
			return true;
		}
		return false;
	},

	savePopupPoint:function(id){
		cc.log("WOULD SAVE HERE!");
	},

	onTouchMoved:function(touch){
		if(this.prevMovPos){
			var pt=touch._point;
			this.panels.setPosition(cc.p(pt.x-this.prevMovPos.x,pt.y-this.prevMovPos.y));
			return true;
		}
	},

	onTouchEnded:function(touch){
		this.prevMovPos=null;
	},

	setupPopup:function(){
		cc.log("Ovveride setupPopup");
	},

	getIdentifier:function(){
		cc.log("No id given... using default 'Popup'");
		return "Popup";
	},

	onTouchEnded:function(touch){
		this.savePopupPoint(this.getIdentifier);
	},

});

InventoryPopup = Popup.extend({

	getIdentifier:function(){
		return "Inventory";
	},
	
	getLayoutObject:function(){
		var inventory_panel = {};
		for(var x=0;x<5;x++){
			for(var y=0;y<8;y++){
				inventory_panel[(5 * y + x)+""]={
					size: cc.size(32,32),
					bg: cc.c4b(140,140,140,200),
					position: cc.p((x*40)+8,(((8-1)-y)*40)+8)
				};
			}
		}
		
		return { 
			"panels":{
				position:cc.p(300,300),
				children:{	
					"main_panel":{
						anchorPoint:cc.p(0,0),
						size: cc.size(208,328),
						bg: cc.c4b(255,255,255,200),
						children: inventory_panel,
					},
					"control_panel":{
						anchorPoint:cc.p(0,0),
						position: cc.p(0,328),
						size: cc.size(208,32),
						bg: cc.c4b(255,0,0,200),
						children:{	
							"header":{
								label:"Inventory",
								fontSize:20,
								anchorPoint:cc.p(0,0.5),
								position:cc.p(8,16),
							}
						}
					},
				}	
			}
		};
	},
});

EquipmentPopup = Popup.extend({

	getIdentifier:function(){
		return "Equipment";
	},
	
	getLayoutObject:function(){
		var itemBox = {
			size: cc.size(32,32),
			bg: cc.c4b(140,140,140,200),
		};
		var equipment_panel = {
			"head": merge_objects(itemBox,{ position:cc.p(88,128)}),
			"body": merge_objects(itemBox,{ position: cc.p(88,88)}),
			"legs": merge_objects(itemBox,{ position: cc.p(88,48)}),
			"feet": merge_objects(itemBox,{ position: cc.p(88,8)}),
			"weapon": merge_objects(itemBox,{ position: cc.p(48,88)}),
			"shield": merge_objects(itemBox,{ position: cc.p(128,88)}),
			"ammo": merge_objects(itemBox,{ position: cc.p(8,128)}),
		}
		
		return {
			"panels":{
				position:cc.p(100,300),
				children:{	
					"main_panel":{
						anchorPoint:cc.p(0,0),
						size: cc.size(168,168),
						bg: cc.c4b(255,255,255,200),
						children: equipment_panel,
					},
					"control_panel":{
						anchorPoint:cc.p(0,0),
						position: cc.p(0,168),
						size: cc.size(168,32),
						bg: cc.c4b(255,0,0,200),
						children:{	
							"header":{
								label:"Equipment",
								fontSize:20,
								anchorPoint:cc.p(0,0.5),
								position:cc.p(8,16),
							}
						}
					},
				}	
			}
		};
	},

});

MapEditor = Popup.extend({
	map:null,
	editMode:"tiles",
	lastTile:null,
	
	getLayoutObject:function(){
		return { "panels":{
				position:cc.p(300,10),
				children:{	
					"main_panel":{
						anchorPoint:cc.p(0,0),
						position: cc.p(0,0),
						size: cc.size(420,352),
						bg: cc.c4b(0,0,100,120),
						children: {
							"tiles" : {
								anchorPoint:cc.p(0,1),
								position:cc.p(16,336),
								texture:"tiles1.png",
							},
							"deletebtn" : {
								position:cc.p(356,316),
								size:cc.size(60,32),
								bg: cc.c4b(255,255,255,255),
								anchorPoint:cc.p(0,0),
								children:{
									"text":{
										label:"Erase",
										fontSize:12,
										anchorPoint:cc.p(0.5,0.5),
										position:cc.p(32,16),
										color:cc.c3b(0,0,0),
									}
								}
							},
							"leftbtn" : {
								position:cc.p(0,16),
								size:cc.size(16,320),
								bg: cc.c4b(0,0,255,255),
								anchorPoint:cc.p(0,0),
								children:{
									"text":{
										label:"<",
										fontSize:12,
										anchorPoint:cc.p(0.5,0.5),
										position:cc.p(8,160),
										color:cc.c3b(255,255,255),
									}
								}
							},
							"rightbtn" : {
								position:cc.p(336,16),
								size:cc.size(16,320),
								bg: cc.c4b(0,0,255,255),
								anchorPoint:cc.p(0,0),
								children:{
									"text":{
										label:">",
										fontSize:12,
										anchorPoint:cc.p(0.5,0.5),
										position:cc.p(8,160),
										color:cc.c3b(255,255,255),
									}
								}
							},
							"upbtn" : {
								position:cc.p(16,336),
								size:cc.size(320,16),
								bg: cc.c4b(0,0,255,255),
								anchorPoint:cc.p(0,0),
								children:{
									"text":{
										label:"^",
										fontSize:12,
										anchorPoint:cc.p(0.5,0.5),
										position:cc.p(160,8),
										color:cc.c3b(255,255,255),
									}
								}
							},
							"downbtn" : {
								position:cc.p(16,0),
								size:cc.size(320,16),
								bg: cc.c4b(0,0,255,255),
								anchorPoint:cc.p(0,0),
								children:{
									"text":{
										label:"v",
										fontSize:12,
										anchorPoint:cc.p(0.5,0.5),
										position:cc.p(160,8),
										color:cc.c3b(255,255,255),
									}
								}
							},
							"blockbtn" : {
								position:cc.p(356,280),
								size:cc.size(60,32),
								bg: cc.c4b(255,255,255,255),
								anchorPoint:cc.p(0,0),
								children:{
									"text":{
										label:"Block",
										fontSize:12,
										anchorPoint:cc.p(0.5,0.5),
										position:cc.p(32,16),
										color:cc.c3b(0,0,0),
									}
								}
							},
							"fillbtn" : {
								position:cc.p(356,244),
								size:cc.size(60,32),
								bg: cc.c4b(255,255,255,255),
								anchorPoint:cc.p(0,0),
								children:{
									"text":{
										label:"Fill",
										fontSize:12,
										anchorPoint:cc.p(0.5,0.5),
										position:cc.p(32,16),
										color:cc.c3b(0,0,0),
									}
								}
							},
							"mapUp_text":{
								label:"Map Up",
								fontSize:10,
								anchorPoint:cc.p(0,0),
								position: cc.p(360,222),
							},
							"mapUp_entry":{
								size: cc.size(60,32),
								position: cc.p(356,194),
							},
							"mapDown_text":{
								label:"Map Down",
								fontSize:10,
								anchorPoint:cc.p(0,0),
								position: cc.p(360,182),
							},
							"mapDown_entry":{
								size: cc.size(60,32),
								position: cc.p(356,154),
							},
							"mapLeft_text":{
								label:"Map Left",
								fontSize:10,
								anchorPoint:cc.p(0,0),
								position: cc.p(360,142),
							},
							"mapLeft_entry":{
								size: cc.size(60,32),
								position: cc.p(356,114),
							},
							"mapRight_text":{
								label:"Map Right",
								fontSize:10,
								anchorPoint:cc.p(0,0),
								position: cc.p(360,102),
							},
							"mapRight_entry":{
								size: cc.size(60,32),
								position: cc.p(356,74),
							},
							"clearbtn" : {
								position:cc.p(356,4),
								size:cc.size(60,32),
								bg: cc.c4b(255,255,255,255),
								anchorPoint:cc.p(0,0),
								children:{
									"text":{
										label:"Clear",
										fontSize:12,
										anchorPoint:cc.p(0.5,0.5),
										position:cc.p(32,16),
										color:cc.c3b(0,0,0),
									}
								}
							},
							"highlightnode" : {
								anchorPoint:cc.p(0,0),
								position:cc.p(0,0),
								size:cc.size(32,32),
								bg:cc.c4b(255,100,100,255),
							},
							"selectednode" : {
								anchorPoint:cc.p(0,0),
								position:cc.p(0,0),
								size:cc.size(32,32),
								bg:cc.c4b(100,255,100,255),
							}
						}
					},
					"control_panel":{
						anchorPoint:cc.p(0,0),
						position: cc.p(0,352),
						size: cc.size(420,32),
						bg: cc.c4b(255,0,0,200),
						children:{	
							"header":{
								label:"Map Editor - Map #" + GameMap.getMapNumber(),
								fontSize:20,
								anchorPoint:cc.p(0,0.5),
								position:cc.p(8,16),
							}
						}
					},
				}
			}
		};
	},
	
	getIdentifier:function(){
		return "MapEditor";
	},
	mapOffset:null,
	mapUpBox:null,
	mapDownBox:null,
	mapLeftBox:null,
	mapRightBox:null,
	
	init:function(_map){
		this._super();
		this.map =_map;
		this.mapOffset=cc.p(0,0);
	},
	
	didBecomeActive:function(){
		this._super();
		this.panels["main_panel"]["highlightnode"].setOpacity(0);
		this.panels["main_panel"]["selectednode"].setOpacity(0);
		this.mapUpBox = new EntryBox(this.panels["main_panel"]["mapUp_entry"],cc.size(this.panels["main_panel"]["mapUp_entry"].getContentSize().width,this.panels["main_panel"]["mapUp_entry"].getContentSize().height), cc.p(0,this.panels["main_panel"]["mapUp_entry"].getContentSize().height), GameMap.hasMapUp() ? GameMap.getMapUp():"", cc.c4b(100,100,100), cc.c3b(255,255,255));
		this.mapUpBox.setDefaultFineFlag(true);
		this.mapDownBox = new EntryBox(this.panels["main_panel"]["mapDown_entry"],cc.size(this.panels["main_panel"]["mapDown_entry"].getContentSize().width,this.panels["main_panel"]["mapDown_entry"].getContentSize().height), cc.p(0,this.panels["main_panel"]["mapDown_entry"].getContentSize().height), GameMap.hasMapDown() ? GameMap.getMapDown():"", cc.c4b(100,100,100), cc.c3b(255,255,255));
		this.mapDownBox.setDefaultFineFlag(true);
		this.mapLeftBox = new EntryBox(this.panels["main_panel"]["mapLeft_entry"],cc.size(this.panels["main_panel"]["mapLeft_entry"].getContentSize().width,this.panels["main_panel"]["mapLeft_entry"].getContentSize().height), cc.p(0,this.panels["main_panel"]["mapLeft_entry"].getContentSize().height), GameMap.hasMapLeft() ? GameMap.getMapLeft():"", cc.c4b(100,100,100), cc.c3b(255,255,255));
		this.mapLeftBox.setDefaultFineFlag(true);
		this.mapRightBox = new EntryBox(this.panels["main_panel"]["mapRight_entry"],cc.size(this.panels["main_panel"]["mapRight_entry"].getContentSize().width,this.panels["main_panel"]["mapRight_entry"].getContentSize().height), cc.p(0,this.panels["main_panel"]["mapRight_entry"].getContentSize().height), GameMap.hasMapRight() ? GameMap.getMapRight():"" , cc.c4b(100,100,100), cc.c3b(255,255,255));
		this.mapRightBox.setDefaultFineFlag(true);
	
		this.updateMapOffset();
		GameMap.setStringsVisible(true);
	},
	
	willTerminate:function(){
		var mapConnectors=[];
		mapConnectors[0]= this.mapUpBox.getText()!="" ? this.mapUpBox.getText() : null
		mapConnectors[1]= this.mapDownBox.getText()!="" ? this.mapDownBox.getText() : null
		mapConnectors[2]= this.mapLeftBox.getText()!="" ? this.mapLeftBox.getText() : null
		mapConnectors[3]= this.mapRightBox.getText()!="" ? this.mapRightBox.getText() : null
		GameMap.setMapInfo(mapConnectors);
		GameMap.updateServer();
		GameMap.setStringsVisible(false);
	},
	
	onMouseMoved:function(pos){
		this.panels["main_panel"]["highlightnode"].setOpacity(0);
		var truePos = this.panels["main_panel"]["tiles"].convertToNodeSpace(pos);
		if(truePos.x>=0 && truePos.y>=0 && truePos.x<=this.panels["main_panel"]["tiles"].getContentSize().width && truePos.y<=this.panels["main_panel"]["tiles"].getContentSize().height){
			truePos.x = truePos.x-(truePos.x%32)+16;
			truePos.y = truePos.y-(truePos.y%32)+16;
			
			this.panels["main_panel"]["highlightnode"].setOpacity(127);
			this.panels["main_panel"]["highlightnode"].setPosition(truePos);
			return true;
		} 
	},
	
	updateMapOffset:function(){
		if(this.panels["main_panel"]["tiles"].getTexture() && this.panels["main_panel"]["tiles"].getTexture()._isLoaded==true){
			this.unschedule(this.updateMapOffset);
			this.panels["main_panel"]["tiles"].setTextureRect(cc.rect(Math.floor(32*this.mapOffset.x),Math.floor(32*this.mapOffset.y),this.panels["main_panel"]["tiles"].getContentSize().width<320?this.panels["main_panel"]["tiles"].getContentSize().width:320,this.panels["main_panel"]["tiles"].getContentSize().height<320?this.panels["main_panel"]["tiles"].getContentSize().height:320));
		} else{
			this.schedule(this.updateMapOffset);
		}
	},
	
	onTouchBegan:function(touch){
		if(this._super(touch)){
			return true;
		}
		this.prevMovPos=null;
		var pos = touch._point;
		var truePos = this.panels["main_panel"].convertToNodeSpace(pos);
		if(cc.rectContainsPoint(cc.rect(this.panels["main_panel"]["leftbtn"].getPositionX(),this.panels["main_panel"]["leftbtn"].getPositionY(),this.panels["main_panel"]["leftbtn"].getContentSize().width,this.panels["main_panel"]["leftbtn"].getContentSize().height),truePos)){
			this.mapOffset.x--;
			this.updateMapOffset();
			cc.log("UPDATE");
			return true;
		}
		if(cc.rectContainsPoint(cc.rect(this.panels["main_panel"]["rightbtn"].getPositionX(),this.panels["main_panel"]["rightbtn"].getPositionY(),this.panels["main_panel"]["rightbtn"].getContentSize().width,this.panels["main_panel"]["rightbtn"].getContentSize().height),truePos)){
			this.mapOffset.x++;
			this.updateMapOffset();
			return true;
		}
		if(cc.rectContainsPoint(cc.rect(this.panels["main_panel"]["upbtn"].getPositionX(),this.panels["main_panel"]["upbtn"].getPositionY(),this.panels["main_panel"]["upbtn"].getContentSize().width,this.panels["main_panel"]["upbtn"].getContentSize().height),truePos)){
			this.mapOffset.y--;
			this.updateMapOffset();
			return true;
		}
		if(cc.rectContainsPoint(cc.rect(this.panels["main_panel"]["downbtn"].getPositionX(),this.panels["main_panel"]["downbtn"].getPositionY(),this.panels["main_panel"]["downbtn"].getContentSize().width,this.panels["main_panel"]["downbtn"].getContentSize().height),truePos)){
			this.mapOffset.y++;
			this.updateMapOffset();
			return true;
		}
		SceneManager.setActiveScene(this);
		truePos = this.panels["main_panel"]["tiles"].convertToNodeSpace(pos);
		if(truePos.x>=0 && truePos.y>=0 && truePos.x<=this.panels["main_panel"]["tiles"].getContentSize().width && truePos.y<=this.panels["main_panel"]["tiles"].getContentSize().height){
			truePos.x = truePos.x-(truePos.x%32)+16;
			truePos.y = truePos.y-(truePos.y%32)+16;
			
			if(this.panels["main_panel"]["selectednode"].getPositionX()!=truePos.x || this.panels["main_panel"]["selectednode"].getPositionY()!=truePos.y){
				this.panels["main_panel"]["selectednode"].setOpacity(127);
				this.panels["main_panel"]["selectednode"].setPosition(truePos);
			} else{
				this.panels["main_panel"]["selectednode"].setOpacity(0);
			}
			return true;
		} 
		
		var globalErasePos = this.panels["main_panel"]["deletebtn"].convertToWorldSpace(cc.p(0,0));
		if(cc.rectContainsPoint(cc.rect(globalErasePos.x,globalErasePos.y,this.panels["main_panel"]["deletebtn"].getContentSize().width,this.panels["main_panel"]["deletebtn"].getContentSize().height),touch._point)){
			this.editMode=this.editMode=="erasing" ? "tiles" : "erasing";
			if(this.editMode=="erasing"){
				this.panels["main_panel"]["blockbtn"].setColor(cc.c4b(255,255,255,255));
				this.panels["main_panel"]["fillbtn"].setColor(cc.c4b(255,255,255,255));
				this.panels["main_panel"]["deletebtn"].setColor(cc.c4b(255,0,0,255));
			} else{
				this.panels["main_panel"]["deletebtn"].setColor(cc.c4b(255,255,255,255));
			}
			return true;
		}
		var globalBlockPos = this.panels["main_panel"]["blockbtn"].convertToWorldSpace(cc.p(0,0));
		if(cc.rectContainsPoint(cc.rect(globalBlockPos.x,globalBlockPos.y,this.panels["main_panel"]["blockbtn"].getContentSize().width,this.panels["main_panel"]["blockbtn"].getContentSize().height),touch._point)){
			this.editMode = this.editMode=="blocking" ? "tiles" : "blocking";
			if(this.editMode=="blocking"){
				this.panels["main_panel"]["deletebtn"].setColor(cc.c4b(255,255,255,255));
				this.panels["main_panel"]["fillbtn"].setColor(cc.c4b(255,255,255,255));
				this.panels["main_panel"]["blockbtn"].setColor(cc.c4b(255,0,0,255));
			} else{
				this.panels["main_panel"]["blockbtn"].setColor(cc.c4b(255,255,255,255));
			}
			return true;
		}
		var globalFillPos = this.panels["main_panel"]["fillbtn"].convertToWorldSpace(cc.p(0,0));
		if(cc.rectContainsPoint(cc.rect(globalFillPos.x,globalFillPos.y,this.panels["main_panel"]["fillbtn"].getContentSize().width,this.panels["main_panel"]["fillbtn"].getContentSize().height),touch._point)){
			this.editMode = this.editMode=="filling" ? "tiles" : "filling";
			if(this.editMode=="filling"){
				this.panels["main_panel"]["deletebtn"].setColor(cc.c4b(255,255,255,255));
				this.panels["main_panel"]["blockbtn"].setColor(cc.c4b(255,255,255,255));
				this.panels["main_panel"]["fillbtn"].setColor(cc.c4b(255,0,0,255));
			} else{
				this.panels["main_panel"]["fillbtn"].setColor(cc.c4b(255,255,255,255));
			}
			return true;
		}
		var globalClearPos = this.panels["main_panel"]["clearbtn"].convertToWorldSpace(cc.p(0,0));
		if(cc.rectContainsPoint(cc.rect(globalClearPos.x,globalClearPos.y,this.panels["main_panel"]["clearbtn"].getContentSize().width,this.panels["main_panel"]["clearbtn"].getContentSize().height),touch._point)){
			GameMap.destroy();
		}
		
		
		/*var globalErasePos = this.panels["main_panel"]["deletebtn"].convertToWorldSpace(cc.p(0,0));
		if(cc.rectContainsPoint(cc.rect(globalErasePos.x,globalErasePos.y,this.panels["main_panel"]["deletebtn"].getContentSize().width,this.panels["main_panel"]["deletebtn"].getContentSize().height),touch._point)){
			this.isDelete=!this.isDelete;
			if(this.isDelete){
				this.panels["main_panel"]["deletebtn"].setColor(cc.c4b(255,0,0,255));
			} else{
				this.panels["main_panel"]["deletebtn"].setColor(cc.c4b(255,255,255,255));
			}
			return true;
		}*/
		return false;
	},	
	
	tilePressed:function(tile,tilenum,touchtype){
		if(this.editMode=="filling" && touchtype=="moved"){
			return false;
		}
		if(tile==this.lastTile && touchtype=="moved"){
			return false;
		}
		this.lastTile=tile;
		switch(this.editMode){
			case "tiles":
				if(this.panels["main_panel"]["selectednode"].getOpacity()!=0){
					GameMap.pushLayer(tilenum,"tiles1.png",cc.p(((this.panels["main_panel"]["selectednode"].getPositionX()-16)/32)+this.mapOffset.x,(9-((this.panels["main_panel"]["selectednode"].getPositionY()-16)/32))+this.mapOffset.y),"ground");
				}
			break;
			case "blocking":
				if(tile.getType()!=1){
					GameMap.setTileInfo(tilenum,1);
				} else{
					GameMap.setTileInfo(tilenum,0);
				}
			break;
			case "erasing":
				GameMap.popLayer(tilenum);
			break;
			case "filling":
				if(this.panels["main_panel"]["selectednode"].getOpacity()!=0){
					GameMap.fillMap("tiles1.png",cc.p(((this.panels["main_panel"]["selectednode"].getPositionX()-16)/32)+this.mapOffset.x,(9-((this.panels["main_panel"]["selectednode"].getPositionY()-16)/32))+this.mapOffset.y),"ground");
				}
			break;
		}
		
	}
});


ItemEditor = Popup.extend({
	
	getLayoutObject:function(){
		return { "panels":{
				position:cc.p(300,10),
				children:{	
					"main_panel":{
						anchorPoint:cc.p(0,0),
						position: cc.p(0,0),
						size: cc.size(420,352),
						bg: cc.c4b(0,0,100,120),
						children: {
							"items" : {
								anchorPoint:cc.p(0,1),
								position:cc.p(16,336),
								texture:"items1.png",
							},
							"deletebtn" : {
								position:cc.p(356,316),
								size:cc.size(60,32),
								bg: cc.c4b(255,255,255,255),
								anchorPoint:cc.p(0,0),
								children:{
									"text":{
										label:"Erase",
										fontSize:12,
										anchorPoint:cc.p(0.5,0.5),
										position:cc.p(32,16),
										color:cc.c3b(0,0,0),
									}
								}
							},
							"leftbtn" : {
								position:cc.p(0,16),
								size:cc.size(16,320),
								bg: cc.c4b(0,0,255,255),
								anchorPoint:cc.p(0,0),
								children:{
									"text":{
										label:"<",
										fontSize:12,
										anchorPoint:cc.p(0.5,0.5),
										position:cc.p(8,160),
										color:cc.c3b(255,255,255),
									}
								}
							},
							"rightbtn" : {
								position:cc.p(336,16),
								size:cc.size(16,320),
								bg: cc.c4b(0,0,255,255),
								anchorPoint:cc.p(0,0),
								children:{
									"text":{
										label:">",
										fontSize:12,
										anchorPoint:cc.p(0.5,0.5),
										position:cc.p(8,160),
										color:cc.c3b(255,255,255),
									}
								}
							},
							"upbtn" : {
								position:cc.p(16,336),
								size:cc.size(320,16),
								bg: cc.c4b(0,0,255,255),
								anchorPoint:cc.p(0,0),
								children:{
									"text":{
										label:"^",
										fontSize:12,
										anchorPoint:cc.p(0.5,0.5),
										position:cc.p(160,8),
										color:cc.c3b(255,255,255),
									}
								}
							},
							"downbtn" : {
								position:cc.p(16,0),
								size:cc.size(320,16),
								bg: cc.c4b(0,0,255,255),
								anchorPoint:cc.p(0,0),
								children:{
									"text":{
										label:"v",
										fontSize:12,
										anchorPoint:cc.p(0.5,0.5),
										position:cc.p(160,8),
										color:cc.c3b(255,255,255),
									}
								}
							},
							"highlightnode" : {
								anchorPoint:cc.p(0,0),
								position:cc.p(0,0),
								size:cc.size(32,32),
								bg:cc.c4b(255,100,100,255),
							},
							"selectednode" : {
								anchorPoint:cc.p(0,0),
								position:cc.p(0,0),
								size:cc.size(32,32),
								bg:cc.c4b(100,255,100,255),
							}
						}
					},
					"control_panel":{
						anchorPoint:cc.p(0,0),
						position: cc.p(0,352),
						size: cc.size(420,32),
						bg: cc.c4b(255,0,0,200),
						children:{	
							"header":{
								label:"Item Editor",
								fontSize:20,
								anchorPoint:cc.p(0,0.5),
								position:cc.p(8,16),
							}
						}
					},
				}
			}
		};

	},
	
	getIdentifier:function(){
		return "ItemEditor";
	},
	mapOffset:null,
	
	init:function(_map){
		this._super();
		this.map =_map;
		this.mapOffset=cc.p(0,0);
	},
	
	didBecomeActive:function(){
		this._super();
		this.panels["main_panel"]["highlightnode"].setOpacity(0);
		this.panels["main_panel"]["selectednode"].setOpacity(0);
		this.updateMapOffset();
	},
	
	willTerminate:function(){
		GameMap.updateServer();
		GameMap.setStringsVisible(false);
	},
	
	onMouseMoved:function(pos){
		this.panels["main_panel"]["highlightnode"].setOpacity(0);
		var truePos = this.panels["main_panel"]["items"].convertToNodeSpace(pos);
		if(truePos.x>=0 && truePos.y>=0 && truePos.x<=this.panels["main_panel"]["items"].getContentSize().width && truePos.y<=this.panels["main_panel"]["items"].getContentSize().height){
			truePos.x = truePos.x-(truePos.x%32)+16;
			truePos.y = truePos.y-(truePos.y%32)+16;
			
			this.panels["main_panel"]["highlightnode"].setOpacity(127);
			this.panels["main_panel"]["highlightnode"].setPosition(truePos);
			return true;
		} 
	},
	
	updateMapOffset:function(){
		if(this.panels["main_panel"]["items"].getTexture() && this.panels["main_panel"]["items"].getTexture()._isLoaded==true){
			this.unschedule(this.updateMapOffset);
			this.panels["main_panel"]["items"].setTextureRect(cc.rect(Math.floor(32*this.mapOffset.x),Math.floor(32*this.mapOffset.y),this.panels["main_panel"]["items"].getContentSize().width<320?this.panels["main_panel"]["items"].getContentSize().width:320,this.panels["main_panel"]["items"].getContentSize().height<320?this.panels["main_panel"]["items"].getContentSize().height:320));
		} else{
			this.schedule(this.updateMapOffset);
		}
	},
	
	
	onTouchBegan:function(touch){
		if(this._super(touch)){
			return true;
		}
		this.prevMovPos=null;
		var pos = touch._point;
		var truePos = this.panels["main_panel"].convertToNodeSpace(pos);
		if(cc.rectContainsPoint(cc.rect(this.panels["main_panel"]["leftbtn"].getPositionX(),this.panels["main_panel"]["leftbtn"].getPositionY(),this.panels["main_panel"]["leftbtn"].getContentSize().width,this.panels["main_panel"]["leftbtn"].getContentSize().height),truePos)){
			this.mapOffset.x--;
			this.updateMapOffset();
			cc.log("UPDATE");
			return true;
		}
		if(cc.rectContainsPoint(cc.rect(this.panels["main_panel"]["rightbtn"].getPositionX(),this.panels["main_panel"]["rightbtn"].getPositionY(),this.panels["main_panel"]["rightbtn"].getContentSize().width,this.panels["main_panel"]["rightbtn"].getContentSize().height),truePos)){
			this.mapOffset.x++;
			this.updateMapOffset();
			return true;
		}
		if(cc.rectContainsPoint(cc.rect(this.panels["main_panel"]["upbtn"].getPositionX(),this.panels["main_panel"]["upbtn"].getPositionY(),this.panels["main_panel"]["upbtn"].getContentSize().width,this.panels["main_panel"]["upbtn"].getContentSize().height),truePos)){
			this.mapOffset.y--;
			this.updateMapOffset();
			return true;
		}
		if(cc.rectContainsPoint(cc.rect(this.panels["main_panel"]["downbtn"].getPositionX(),this.panels["main_panel"]["downbtn"].getPositionY(),this.panels["main_panel"]["downbtn"].getContentSize().width,this.panels["main_panel"]["downbtn"].getContentSize().height),truePos)){
			this.mapOffset.y++;
			this.updateMapOffset();
			return true;
		}
		SceneManager.setActiveScene(this);
		truePos = this.panels["main_panel"]["tiles"].convertToNodeSpace(pos);
		if(truePos.x>=0 && truePos.y>=0 && truePos.x<=this.panels["main_panel"]["tiles"].getContentSize().width && truePos.y<=this.panels["main_panel"]["tiles"].getContentSize().height){
			truePos.x = truePos.x-(truePos.x%32)+16;
			truePos.y = truePos.y-(truePos.y%32)+16;
			
			if(this.panels["main_panel"]["selectednode"].getPositionX()!=truePos.x || this.panels["main_panel"]["selectednode"].getPositionY()!=truePos.y){
				this.panels["main_panel"]["selectednode"].setOpacity(127);
				this.panels["main_panel"]["selectednode"].setPosition(truePos);
			} else{
				this.panels["main_panel"]["selectednode"].setOpacity(0);
			}
			return true;
		} 
		
		var globalErasePos = this.panels["main_panel"]["deletebtn"].convertToWorldSpace(cc.p(0,0));
		if(cc.rectContainsPoint(cc.rect(globalErasePos.x,globalErasePos.y,this.panels["main_panel"]["deletebtn"].getContentSize().width,this.panels["main_panel"]["deletebtn"].getContentSize().height),touch._point)){
			this.editMode=this.editMode=="erasing" ? "tiles" : "erasing";
			if(this.editMode=="erasing"){
				this.panels["main_panel"]["blockbtn"].setColor(cc.c4b(255,255,255,255));
				this.panels["main_panel"]["fillbtn"].setColor(cc.c4b(255,255,255,255));
				this.panels["main_panel"]["deletebtn"].setColor(cc.c4b(255,0,0,255));
			} else{
				this.panels["main_panel"]["deletebtn"].setColor(cc.c4b(255,255,255,255));
			}
			return true;
		}
		var globalBlockPos = this.panels["main_panel"]["blockbtn"].convertToWorldSpace(cc.p(0,0));
		if(cc.rectContainsPoint(cc.rect(globalBlockPos.x,globalBlockPos.y,this.panels["main_panel"]["blockbtn"].getContentSize().width,this.panels["main_panel"]["blockbtn"].getContentSize().height),touch._point)){
			this.editMode = this.editMode=="blocking" ? "tiles" : "blocking";
			if(this.editMode=="blocking"){
				this.panels["main_panel"]["deletebtn"].setColor(cc.c4b(255,255,255,255));
				this.panels["main_panel"]["fillbtn"].setColor(cc.c4b(255,255,255,255));
				this.panels["main_panel"]["blockbtn"].setColor(cc.c4b(255,0,0,255));
			} else{
				this.panels["main_panel"]["blockbtn"].setColor(cc.c4b(255,255,255,255));
			}
			return true;
		}
		var globalFillPos = this.panels["main_panel"]["fillbtn"].convertToWorldSpace(cc.p(0,0));
		if(cc.rectContainsPoint(cc.rect(globalFillPos.x,globalFillPos.y,this.panels["main_panel"]["fillbtn"].getContentSize().width,this.panels["main_panel"]["fillbtn"].getContentSize().height),touch._point)){
			this.editMode = this.editMode=="filling" ? "tiles" : "filling";
			if(this.editMode=="filling"){
				this.panels["main_panel"]["deletebtn"].setColor(cc.c4b(255,255,255,255));
				this.panels["main_panel"]["blockbtn"].setColor(cc.c4b(255,255,255,255));
				this.panels["main_panel"]["fillbtn"].setColor(cc.c4b(255,0,0,255));
			} else{
				this.panels["main_panel"]["fillbtn"].setColor(cc.c4b(255,255,255,255));
			}
			return true;
		}
		var globalClearPos = this.panels["main_panel"]["clearbtn"].convertToWorldSpace(cc.p(0,0));
		if(cc.rectContainsPoint(cc.rect(globalClearPos.x,globalClearPos.y,this.panels["main_panel"]["clearbtn"].getContentSize().width,this.panels["main_panel"]["clearbtn"].getContentSize().height),touch._point)){
			GameMap.destroy();
		}
		
		
		/*var globalErasePos = this.panels["main_panel"]["deletebtn"].convertToWorldSpace(cc.p(0,0));
		if(cc.rectContainsPoint(cc.rect(globalErasePos.x,globalErasePos.y,this.panels["main_panel"]["deletebtn"].getContentSize().width,this.panels["main_panel"]["deletebtn"].getContentSize().height),touch._point)){
			this.isDelete=!this.isDelete;
			if(this.isDelete){
				this.panels["main_panel"]["deletebtn"].setColor(cc.c4b(255,0,0,255));
			} else{
				this.panels["main_panel"]["deletebtn"].setColor(cc.c4b(255,255,255,255));
			}
			return true;
		}*/
		return false;
	},	
	
	tilePressed:function(tile,tilenum,touchtype){
		if(this.editMode=="filling" && touchtype=="moved"){
			return false;
		}
		if(tile==this.lastTile && touchtype=="moved"){
			return false;
		}
		this.lastTile=tile;
		switch(this.editMode){
			case "tiles":
				if(this.panels["main_panel"]["selectednode"].getOpacity()!=0){
					GameMap.pushLayer(tilenum,"tiles1.png",cc.p(((this.panels["main_panel"]["selectednode"].getPositionX()-16)/32)+this.mapOffset.x,(9-((this.panels["main_panel"]["selectednode"].getPositionY()-16)/32))+this.mapOffset.y),"ground");
				}
			break;
			case "blocking":
				if(tile.getType()!=1){
					GameMap.setTileInfo(tilenum,1);
				} else{
					GameMap.setTileInfo(tilenum,0);
				}
			break;
			case "erasing":
				GameMap.popLayer(tilenum);
			break;
			case "filling":
				if(this.panels["main_panel"]["selectednode"].getOpacity()!=0){
					GameMap.fillMap("tiles1.png",cc.p(((this.panels["main_panel"]["selectednode"].getPositionX()-16)/32)+this.mapOffset.x,(9-((this.panels["main_panel"]["selectednode"].getPositionY()-16)/32))+this.mapOffset.y),"ground");
				}
			break;
		}
		
	}
});



