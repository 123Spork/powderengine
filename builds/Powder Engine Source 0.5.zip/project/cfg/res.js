var res = {
    items1_png : 'items1.png',
    sprites1_png : 'sprites1.png',
    tiles1_png : 'tiles1.png'
};