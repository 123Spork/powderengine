var LocalStorage=cc.Class.extend({
	instance:null,
	
	getLastUpdate:function(objectType){
		var date = sys.localStorage.getItem("last_"+objectType);
		return date ? date : null;
	},

	setLastUpdate:function(objectType,date){
		var date = sys.localStorage.setItem("last_"+objectType,date);
		return date ? date : null;
	},
	
});

LocalStorage.Create = function(){
	if(!this.instance){
		this.instance = new LocalStorage();
	}
	return this.instance;
};

LocalStorage.getInstance=function(){
	return this.instance;
};

LocalStorage.getMapData=function(mapNumber){
	if(this.instance.getLastUpdate("maps")){
		if(mapNumber){
			var data = JSON.parse(sys.localStorage.getItem("map_data"));
			return data[mapNumber] ? data[mapNumber] :null;
		}
	} else{
		sendMessageToServer({"requestmaps":true});
	}
};

LocalStorage.updateMapData=function(data,updatetime){
	this.instance.setLastUpdate("maps",updatetime);
	sys.localStorage.setItem("map_data",JSON.stringify(data));
};

LocalStorage.changeMap=function(mapNumber,data,updatetime){
	if(!this.instance.getLastUpdate("maps")){
		var maparray = [];
	} else{
		var maparray = JSON.parse(sys.localStorage.getItem("map_data"));
	}
	maparray[mapNumber]=data;
	LocalStorage.updateMapData(maparray,updatetime);
};

LocalStorage.Clear=function(){
	sys.localStorage.setItem("map_data",[]);
	sys.localStorage.setItem("last_maps",0);
};

LocalStorage.Sync=function(){
	sendMessageToServer({"sync":true, "mapupdate":(this.instance.getLastUpdate("maps")!=null ? this.instance.getLastUpdate("maps"):2)});
};

LocalStorage.setMapSaveOnExit=function(value){
	if(value==true || value==false){
		sys.localStorage.setItem("mapedit_saveonexit",value);
	}
};

LocalStorage.getMapSaveOnExit=function(){
	return sys.localStorage.getItem("mapedit_saveonexit")==null?false:sys.localStorage.getItem("mapedit_saveonexit");
};

