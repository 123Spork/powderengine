document["ccConfig"] = {
    COCOS2D_DEBUG: 2,
    showFPS : true,
    frameRate : 60,
    tag : "gameCanvas",
    renderMode:1       //Choose of RenderMode: 0(default), 1(Canvas only), 2(WebGL only)
};