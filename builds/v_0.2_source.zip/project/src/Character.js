Character = cc.Sprite.extend({
	name:null,
	stats:null,
	textureData:null,
	animFrame:null,
	toPosition:null,
	isWalking:false,
	nameLabel:null,
	spriteFrame:null,
	isPlayer:false,
	status:null,


	init:function(withData){
		this.setTextureData(withData.textureName,withData.spriteId);
		this.stats = new StatsController(withData.statData,this);
		this.addChild(this.stats);
		
		this.name = withData.name;
		if(withData.isPlayer){
			this.isPlayer=withData.isPlayer;
		}
		this.setAnchorPoint(0,1);
		this.nameLabel = cc.LabelTTF.create("","Arial",12);
		this.nameLabel.setAnchorPoint(0.5,0);
		this.nameLabel.setColor(255,0,0);
		this.nameLabel.setPosition(Math.floor(this.getContentSize().width/2),this.getContentSize().width+3);
		this.addChild(this.nameLabel);
		this.updateNameString();
	},
	
	updateStatus:function(status){
		if(status && status!=this.status){
			this.status = status;
		} else{
			this.status=null;
		}
		this.updateNameString();
	},
	
	updateNameString:function(){
		if(this.status!=null){
			this.nameLabel.setString(this.name+"-"+this.status);
		} else{
		    this.nameLabel.setString(this.name);
		}
	},
	
	getName:function(){
		return this.name;
	},
	
	setSpriteFrame:function(x,y){
		this.setTextureRect(cc.rect(x*32,((this.textureData.id*4)*32)+(y*32),32,32));
		this.spriteFrame=cc.p(x,y);
	},
	
	getSpriteFrame:function(x,y){
		return this.spriteFrame;
	},
	
	
	setTextureData:function(textureName, spriteId){
		this.textureData = {name:textureName, id:spriteId};
		this.setTexture(cc.TextureCache.getInstance().addImage(textureName));
		this.setSpriteFrame(1,0);
	},
	
	
	
	getGridPosition:function(){
		return cc.p(this.getPosition().x/32,this.getPosition().y/32);
	},
	
	animationCounter:((60/1000)*4),
	velocity: ((60/1000)*4),
	distToMove: 2,
	
	walk:function(dt){
		this.animationCounter+=dt;
		var pos = this.getPosition();
		var sf =this.getSpriteFrame();
		if(this.animationCounter>this.velocity){
			this.animationCounter=0;
			if(this.toPosition.x<pos.x){
				this.setSpriteFrame((sf.x+1)%3,1);
			} else if(this.toPosition.x>pos.x){
				this.setSpriteFrame((sf.x+1)%3,2);
			} else if(this.toPosition.y<pos.y){
				this.setSpriteFrame((sf.x+1)%3,0);
			} else if(this.toPosition.y>pos.y){
				this.setSpriteFrame((sf.x+1)%3,3);
			}
		}
			
		if(this.toPosition.x<pos.x){
			this.setPositionX(pos.x-this.distToMove);
		} else if(this.toPosition.x>pos.x){
			this.setPositionX(pos.x+this.distToMove);
		} else if(this.toPosition.y<pos.y){
			this.setPositionY(pos.y-this.distToMove);
		} else if(this.toPosition.y>pos.y){
			this.setPositionY(pos.y+this.distToMove);
		}
		if(pos.y==this.toPosition.y && pos.x==this.toPosition.x){
			this.isWalking=false;
			this.unschedule(this.walk);
		}
	
	
	},
	
	walkTo:function(x,y,tile,name){
		if(this.isWalking==false && tile){
			var sf = this.spriteFrame;
			var gp = this.getGridPosition();
			if(gp.x>x){
				this.setSpriteFrame(sf.x,1);
			} else if(gp.x<x){
				this.setSpriteFrame(sf.x,2);
			} if(gp.y>y){
				this.setSpriteFrame(sf.x,0);
			} else if(gp.y<y){
				this.setSpriteFrame(sf.x,3);
			}
			switch(tile.getType()){
				case 0: break;
				case 1: return;
			}
			this.toPosition = cc.p(32*x,32*y);
			this.isWalking=true;
			this.schedule(this.walk);
			this.walk(0);
			if(this.isPlayer){
				sendMessageToServer({"moveTo":((this.toPosition.x/32) + ((this.toPosition.y/32) * gridWidth))});
			}
		}
	},

	walkToIndex:function(index){
		var x=index % gridWidth;
		var y=Math.floor(index/gridWidth); 
		if(this.isWalking==false){
			var sf = this.spriteFrame;
			var gp = this.getGridPosition();
			if(gp.x>x){
				this.setSpriteFrame(sf.x,1);
			} else if(gp.x<x){
				this.setSpriteFrame(sf.x,2);
			} else if(gp.y>y){
				this.setSpriteFrame(sf.x,0);
			} else if(gp.y<y){
				this.setSpriteFrame(sf.x,3);
			}
			this.toPosition = cc.p(32*x,32*y);
			this.isWalking=true;
			this.schedule(this.walk);
			this.walk(0);
		}
	}

	
});

PlayerCharacter = Character.extend({
	items:null,
	init:function(withData){
		this._super(withData);
		this.items = {stored:{}, equipped:{}};
	},
});
PlayerCharacter.create = function(withData){
	var playerCharacter = new PlayerCharacter();
	playerCharacter.init(withData);
	return playerCharacter;
};

NonPlayerCharacter = Character.extend({
	loot:null,
});