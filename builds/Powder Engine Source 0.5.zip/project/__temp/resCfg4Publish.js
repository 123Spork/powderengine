var js = {
    project : {
        SceneManager_js : "_0"
    }
};
cc.res4GameModules = {};
cc.res4GameModules[js.project.SceneManager_js]=[
];
cc.res4GameModules.base =[
];
