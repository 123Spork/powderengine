// Require HTTP module (to start server) and Socket.IO
var http = require('http');
var io = require('socket.io');


var fs = require('fs')
fs.readFile('project/config.txt', 'utf8', function (err,data) {
var port = parseInt(data.split("\n")[1]);
  
var positions = [];
var clients =[];
var names=[];

// Start the server at port 8080
var server = http.createServer(function(req, res){ 
    // Send HTML headers and message
    res.writeHead(200,{ 'Content-Type': 'text/html' }); 
    res.end('<h1>Hello Socket Lover!</h1>');
});

server.listen(port);

// Create a Socket.IO instance, passing it our server
var socket = io.listen(server);

socket.on('message',function(data) {
  console.log('Received a message from the server!',data);
});




// Add a connect listener
socket.on('connection', function(client){ 
    // Success!  Now listen to messages to be received
    client.on('message',function(event){
		event = JSON.parse(event);
		if(event["login"]){
			for(var i in names){
				if(names[i]==event["username"]){
					client.send(JSON.stringify({"login_fail":"Username in use already."}));
					return;
				}
			}
			if(names.indexOf(event["username"])==-1){
				client.send(JSON.stringify({"login_success":true}));
				names[client.id]=event["username"];
				clients[client.id]=true;
				client.broadcast.send(JSON.stringify({"newPlayer":event["username"]}));
				for(var i in clients){
					if(i!=client.id && clients[i]==true){
						if(positions[i]){
							client.send(JSON.stringify({"moveTo":positions[i],"id":names[i]}));
						} else{
							client.send(JSON.stringify({"moveTo":"default","id":names[i]}));
						}
					}
				}
			}
		}
		if(event["moveTo"]){
			client.broadcast.send(JSON.stringify({"moveTo":event["moveTo"],"id":names[client.id]}));
			positions[client.id]= event["moveTo"];
		}
		if(event["chatMessage"]){
			client.broadcast.send(JSON.stringify({"chatMessage":names[client.id]+": "+event["chatMessage"]}));
		}
		if(event["logout"]){
			client.broadcast.send(JSON.stringify({"playerLeft":names[client.id]}));
			names[client.id]=undefined;
			positions[client.id]=undefined;
		}
		if(event["disconnect"]){
			client.broadcast.send(JSON.stringify({"playerLeft":names[client.id]}));
			clients[client.id]=undefined;
			names[client.id]=undefined;
			positions[client.id]=undefined;
		}
		if(event["diceroll"]){
			client.broadcast.send(JSON.stringify({"diceroll":event["diceroll"]}));
		}
		if(event["coinflip"]){
			client.broadcast.send(JSON.stringify({"coinflip":event["coinflip"]}));
		}
		if(event["dance"]){
			client.broadcast.send(JSON.stringify({"dance":event["dance"]}));
		}
		if(event["afk"]){
			var number = Math.floor( Math.random() * (6 - 1) + 1);
			client.broadcast.send(JSON.stringify({"afk":names[client.id]}));
		}
    });

    client.on('disconnect',function(){
       client.broadcast.send(JSON.stringify({"playerLeft":names[client.id]}));
	   client.send(JSON.stringify({"disconnect":true}));
	   console.log("CLIENT HAS DISCONNECTED");
	   clients[client.id]=undefined;
	   names[client.id]=undefined;
	   positions[client.id]=undefined;
    });
});

  
  
  
  
  
  
});

