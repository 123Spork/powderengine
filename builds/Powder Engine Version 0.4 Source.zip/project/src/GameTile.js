var GameTile = cc.Sprite.extend({
	layers:null,
	position:null,
	string:null,
	type:null,
	
	ctor:function(){
		this._super();
	},
	
	init:function(){
		this.layers=[];
		this._super();
		this.string = cc.LabelTTF.create("","Arial",16);
		this.string.setAnchorPoint(0.5,0.5);
		this.string.setPosition(16,-16);
		this.string.setOpacity(0);
		this.string.setColor(cc.c3b(0,0,0));
		this.addChild(this.string,900);
		

		this.setType(0);
	},
	
	isSameData:function(texture,frame){
		var layer = this.topLayer();
		if(layer && layer.image==texture && layer.frame.x==frame.x && layer.frame.y==frame.y){
			return true;
		}
		return false;
	},
	
	pushLayer:function(_texture,_tilePos,_type){
		var texture = cc.TextureCache.getInstance().addImage(_texture);
		var sprite = cc.Sprite.createWithTexture(texture);
		sprite.setTextureRect(cc.rect(Math.floor(32*_tilePos.x),Math.floor(32*_tilePos.y),32,32));
		sprite.setColor(cc.c4b(255,255,255,255));
		sprite.setAnchorPoint(0,1),
		this.addChild(sprite);
		this.layers.push({sprite:sprite,image:_texture,type:_type,frame:_tilePos});
	},
	
	topLayer:function(){
		if(this.layers.length>0){
			return this.layers[this.layers.length-1];
		}
		return null;
	},
	
	destroy:function(){
		for(var i=0;i<this.layers.length;i++){
			this.layers[i].sprite.removeFromParent();
			this.layers[i]=null;
		}
		this.setType(0);
		this.layers=[];
	},
	
	popLayer:function(){
		if(this.layers.length>0){
			this.layers[this.layers.length-1].sprite.removeFromParent();
			this.layers.splice(this.layers.length-1,1);
		}
	},
	
	setType:function(_in){
		this.type=_in;
		switch(this.type){
			case 0: this.string.setString(""); break;
			case 1: this.string.setString("BLK"); break;
			case 2: this.string.setString("SPW"); break;	
			case 3: this.string.setString("WRP"); break;	
			case 4: this.string.setString("SGN"); break;	
			case 5: this.string.setString("SCR"); break;	
			case 6: this.string.setString("SKL"); break;
		}
	},
	
	setStringVisible:function(_in){
		this.string.setOpacity(_in==true?255:0);
	},
	
	getType:function(){
		return this.type;
	},
	
});

GameTile.Create=function(x,y){
	var tile = new GameTile();
	tile.init();
	tile.position = cc.p(x,y);
	return tile;
};