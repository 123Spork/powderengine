var GameMap=cc.Layer.extend({
	instance:null,
	tileData:null,
	tileNodes:null,
	isMapDirty:false,
	renderTexture:null,
	interactionDelegate:null,
	mapUp:null,
	mapDown:null,
	mapLeft:null,
	mapRight:null,
	currentMap:1,

	setupFromServer:function(data){
		this.tileData=[];
		this.tileData[0]={"tiledata":[]};
		this.tileData[1]={"mapdata":[]};
		for(var i in this.tileNodes){
			if(i.substring(0,4)=="tile"){
				for(var k=0;k<this.tileNodes[i].layers.length;k++){
					this.tileNodes[i].popLayer();
				}
			}
		}
		
		if(data){
			this.tileData=data;
			if(!this.tileData[0]["tiledata"]){
				this.tileData[0]={"tiledata":[]};
			}
			if(!this.tileData[1]["mapdata"]){
				this.tileData[1]={"mapdata":[]};
			}
			for(var i=0;i<data.length;i++){
				if(data[i]!=null && !data[i]["tiledata"] && !data[i]["mapdata"]){
					this.tileNodes[data[i]["id"]].pushLayer(data[i]["texture"],data[i]["frame"],data[i]["type"]);
				} else if(data[i]["tiledata"]){
					for(var j in data[i]["tiledata"]){
						this.tileNodes[data[i]["tiledata"][j]["id"]].setType(data[i]["tiledata"][j]["type"]);
					}
				} else if(data[i]["mapdata"]){
						this.mapUp = data[i]["mapdata"][0] ? data[i]["mapdata"][0] : null;
						this.mapDown = data[i]["mapdata"][1] ? data[i]["mapdata"][1] : null;
						this.mapLeft = data[i]["mapdata"][2] ? data[i]["mapdata"][2] : null;
						this.mapRight = data[i]["mapdata"][3] ? data[i]["mapdata"][3] : null;
				}
			}
		}
		this.schedule(this.refreshRenderTexture);
	},
	
	setup:function(mapnumber){
		var data = LocalStorage.getMapData(mapnumber);
		this.tileData=[];
		this.tileData[0]={"tiledata":[]};
		this.tileData[1]={"mapdata":[]};
		for(var i in this.tileNodes){
			if(i.substring(0,4)=="tile"){
				for(var k=0;k<this.tileNodes[i].layers.length;k++){
					this.tileNodes[i].popLayer();
				}
			}
		}
		
		if(data){
			this.tileData=data;
			if(!this.tileData[0]["tiledata"]){
				this.tileData[0]={"tiledata":[]};
			}
			if(!this.tileData[1]["mapdata"]){
				this.tileData[1]={"mapdata":[]};
			}
			for(var i=0;i<data.length;i++){
				if(data[i]!=null && !data[i]["tiledata"] && !data[i]["mapdata"]){
					this.tileNodes[data[i]["id"]].pushLayer(data[i]["texture"],data[i]["frame"],data[i]["type"]);
				} else if(data[i]["tiledata"]){
					for(var j in data[i]["tiledata"]){
						this.tileNodes[data[i]["tiledata"][j]["id"]].setType(data[i]["tiledata"][j]["type"]);
					}
				} else if(data[i]["mapdata"]){
					this.mapUp = data[i]["mapdata"][0] ? data[i]["mapdata"][0] : null;
					this.mapDown = data[i]["mapdata"][1] ? data[i]["mapdata"][1] : null;
					this.mapLeft = data[i]["mapdata"][2] ? data[i]["mapdata"][2] : null;
					this.mapRight = data[i]["mapdata"][3] ? data[i]["mapdata"][3] : null;
				}
			}
		}
		this.schedule(this.refreshRenderTexture);
	},
	
	refreshRenderTexture:function(){
		for(var i in this.tileNodes){
			if(i.substring(0,4)=="tile"){
				if(!this.tileNodes[i].topLayer() || !this.tileNodes[i].topLayer().sprite.getTexture() ||  this.tileNodes[i].topLayer().sprite.getTexture()._isLoaded==false){
					return;
				}
			}
		}
		this.unschedule(this.refreshRenderTexture);
		this.renderTexture.setVisible(true);
		this.isMapDirty=true;
	},
	
	getLayoutObject:function(){
		var gameTiles={};
		for(var i=0;i<gridWidth;i++){
			for(var j=0;j<gridHeight;j++){
				var index= (i + j*gridWidth);
				gameTiles["tile"+index] = {
					size:cc.size(cellsize,cellsize),
					anchorPoint:cc.p(0,0),
					color:cc.c4b(255,255,255,255),
					position:cc.p(i*cellsize,((gridHeight)-j)*cellsize),
					isGameTile:true,
					tileXY: cc.p(j,i),
					visible:false,
				};
			}
		}
		return {"panels":{children:gameTiles}};
	},
	
	init:function(){
		this.setTouchEnabled(true);
		this.setTouchMode(1);
	},
	
	onTouchBegan:function(touch){
		if(this.interactionDelegate){
			for(var i in this.tileNodes){
				if(i.substring(0,4)=="tile"){
					if(cc.rectContainsPoint(this.tileNodes[i].getBoundingBox(),cc.p(touch._point.x,touch._point.y+32))){
						this.interactionDelegate.tilePressed(this.tileNodes,i);
						GameMap.updateMap();
					}
				}
			}
			return true;
		}
	},
	
	onTouchMoved:function(touch){
		if(this.interactionDelegate){
			for(var i in this.tileNodes){
				if(i.substring(0,4)=="tile"){
					if(cc.rectContainsPoint(this.tileNodes[i].getBoundingBox(),cc.p(touch._point.x,touch._point.y+32))){
						this.interactionDelegate.tilePressed(this.tileNodes,i);
						GameMap.updateMap();
					}
				}
			}
			return true;
		}
	},
		
	visit:function(){
		this._super();
		if(this.isMapDirty==true){
			this.renderTexture.beginWithClear(1,1,1,1);
			for(var i in this.tileNodes){
				if(i.substring(0,4)=="tile"){
				 this.tileNodes[i].setVisible(true);
				 this.tileNodes[i].visit();
				 this.tileNodes[i].setVisible(false);
				}
			}
			this.isMapDirty=false;
			this.renderTexture.end();
		}
	}
	
});

GameMap.create=function(){
	if(!this.instance){
		this.instance = new GameMap();
		this.instance.tileNodes = requestLayout(this.instance);
		this.instance.addChild(this.instance.tileNodes);
		this.instance.renderTexture = cc.RenderTexture.create(gamePanelSize.width,gamePanelSize.height);
		this.instance.renderTexture.setPosition(cc.p(Math.floor(gamePanelSize.width/2),Math.floor(gamePanelSize.height/2)));	
		this.instance.tileNodes.addChild(this.instance.renderTexture);
		this.instance.renderTexture.setVisible(false);
		this.instance.init();
	}
	return this.instance;
};

GameMap.getInstance = function(mapnumber){
	return this.instance;
};

GameMap.setInstanceNull = function(){
	this.instance=null;
};

GameMap.updateMap=function(){
	if(!this.instance){
		this.instance = GameMap.create();
	}
	this.instance.isMapDirty=true;
};

GameMap.setupMap=function(data){
	this.instance.setupFromServer(data);
};

GameMap.getInstance=function(){
	return this.instance;
};

GameMap.pushLayer=function(id,texture,frame,type){
	if(!this.instance.tileNodes[id].isSameData(texture,frame)){
		this.instance.tileNodes[id].pushLayer(texture,frame,type);
		this.instance.tileData.push({"id": id, "texture":texture,"frame":frame,"type":type});
	}
};

GameMap.updateServer=function(){
	sendMessageToServer({"savemap":this.instance.currentMap, "mapdata":this.instance.tileData});
};

GameMap.popLayer=function(id){
	for (var i=this.instance.tileData.length-1;i>=0;i--){
		if(this.instance.tileData[i]["id"]==id){
			this.instance.tileData.splice(i,1);
			break;
		}
	}
	this.instance.tileNodes[id].popLayer();
};

GameMap.setTileInfo=function(id,type){
	this.instance.tileNodes[id].setType(type);
	for(var i in this.instance.tileData[0]["tiledata"]){
		if(this.instance.tileData[0]["tiledata"][i]["id"]==id){
			this.instance.tileData[0]["tiledata"][i]["type"]=type;
			return;
		}
	}
	this.instance.tileData[0]["tiledata"].push({"id":id,"type":type});
};

GameMap.setMapInfo=function(data){
	this.instance.tileData[1]["mapdata"] = data;
	this.instance.mapUp = data[0];
	this.instance.mapDown = data[1];
	this.instance.mapLeft = data[2];
	this.instance.mapRight = data[3];
};


GameMap.fillMap = function(texture,frame,type){
	for(var i in this.instance.tileNodes){
		if(i.substring(0,4)=="tile"){
			if(!this.instance.tileNodes[i].isSameData(texture,frame)){
				this.instance.tileNodes[i].pushLayer(texture,frame,type);
				this.instance.tileData.push({"id": i, "texture":texture,"frame":frame,"type":type});
			}
		}
	}
};

GameMap.setStringsVisible=function(value){
	for(var i in this.instance.tileNodes){
		if(i.substring(0,4)=="tile"){
			this.instance.tileNodes[i].setStringVisible(value);
		}
	}
	this.instance.isMapDirty=true;
};

GameMap.setStringsToIndex=function(){
	for(var i in this.instance.tileNodes){
		if(i.substring(0,4)=="tile"){
			this.instance.tileNodes[i].string.setString(i.substring(4));
		}
	}
	this.instance.isMapDirty=true;
};

GameMap.hasMapUp=function(){
	return this.instance.mapUp!=null;
};

GameMap.hasMapDown=function(){
	return this.instance.mapDown!=null;
};

GameMap.hasMapLeft=function(){
	return this.instance.mapLeft!=null;
};

GameMap.hasMapRight=function(){
	return this.instance.mapRight!=null;
};

GameMap.getMapNumber=function(){
	return this.instance.currentMap;
};

GameMap.getMapUp=function(){
	return this.instance.mapUp;
};

GameMap.getMapDown=function(){
	return this.instance.mapDown;
};

GameMap.getMapLeft=function(){
	return this.instance.mapLeft;
};

GameMap.getMapRight=function(){
	return this.instance.mapRight;
};

GameMap.goToMapUp=function(){
	GameMap.destroy();
	this.instance.currentMap=this.instance.mapUp;
	PlayersController.getYou().setMap(this.instance.mapUp);
	PlayersController.showPlayersInMapOnly();
	this.instance.setup(this.instance.mapUp);
};

GameMap.goToMapDown=function(){
	GameMap.destroy();
	this.instance.currentMap=this.instance.mapDown;
	PlayersController.getYou().setMap(this.instance.mapDown);
	PlayersController.showPlayersInMapOnly();
	this.instance.setup(this.instance.mapDown);
};

GameMap.goToMapLeft=function(){
	GameMap.destroy();
	this.instance.currentMap=this.instance.mapLeft;
	PlayersController.getYou().setMap(this.instance.mapLeft);
	PlayersController.showPlayersInMapOnly();
	this.instance.setup(this.instance.mapLeft);
};

GameMap.goToMapRight=function(){
	GameMap.destroy();
	this.instance.currentMap=this.instance.mapRight;
	PlayersController.getYou().setMap(this.instance.mapRight);
	PlayersController.showPlayersInMapOnly();
	this.instance.setup(this.instance.mapRight);
};

GameMap.setInteractionDelegate=function(delegate){
	this.instance.interactionDelegate=delegate;
};

GameMap.getTileNodeForXY=function(x,y){
	if(x>(gridWidth-1)||x<0){
		return undefined;
	}
	return this.instance.tileNodes["tile"+(x + (gridHeight-y) * gridWidth)];
};

GameMap.destroy=function(){
	for(var i in this.instance.tileNodes){
		if(i.substring(0,4)=="tile"){
			this.instance.tileNodes[i].destroy();
		}
	}
	this.instance.tileData=[];
	this.instance.tileData[0]={"tiledata":[]};
	this.instance.tileData[1]={"mapdata":[]};
	this.instance.isMapDirty=true;
};