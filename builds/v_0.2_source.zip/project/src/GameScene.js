var GameScene = Scene.extend({
	chatbox:null,
	inventory:null,
	equipment:null,
	mapeditor:null,
	tiles:null,
	renderTexture:null,
	isMapDirty:false,
	map:null,
	players:null,
	
	ctor:function(){
		this._super();
	},
	
	willBecomeActive:function(){
		this._super();
	},
	
	didBecomeActive:function(){
		this._super();
	},
	
	willTerminate:function(){
		this._super();
	},
	
	addPlayer:function(id){
		var withData ={
			name: id,
			stats: {
				"health":{level:1,value:100,maxval:200,maxlvl:900},
				"mana":{level:1,value:100,maxval:200,maxlvl:99},
			},
			textureName: "sprites1.png",
			spriteId: 1,
		};
		this.players[id] = PlayerCharacter.create(withData);
		this.players[id].setPosition(320,320);
		this.addChild(this.players[id]);
		this.addChatMessage(id + strings.gameChat.playerJoin,true);
		
	},
	
	destroyPlayer:function(id){
		if(this.players[id]){
			this.players[id].removeFromParent();
			this.players[id]=null;
			this.addChatMessage(id + strings.gameChat.playerLeave,true);
		}
	},
	
	setServerConnected:function(active){
		if(active==false){
			SceneManager.getInstance().goToScene("Login",{serverConnected:false});
		}
	},
	
	movePlayer:function(id,index){
		if(this.players[id] && index!="default"){
			this.players[id].walkToIndex(index);
		} else{
			var withData ={
				name: id,
				stats: {
					"health":{level:1,value:100,maxval:200,maxlvl:900},
					"mana":{level:1,value:100,maxval:200,maxlvl:99},
				},
				textureName: "sprites1.png",
				spriteId: 1,
			};
			this.players[id] = PlayerCharacter.create(withData);
			this.players[id].setPosition(320,320);
			this.players[id].setPosition(cc.p((index % gridWidth)*32,(Math.floor(index/gridWidth))*32)); 
			this.addChild(this.players[id]);
			this.addChatMessage(id + strings.gameChat.playerJoin,true);
		}
	},
	
	//onMouseMoved:function(pos){

	//},

	onTouchBegan:function(touch){
		if(cc.rectContainsPoint(cc.rect(this.panels["logout_button"].getPositionX(),this.panels["logout_button"].getPositionY(),this.panels["logout_button"].getContentSize().width,this.panels["logout_button"].getContentSize().height),touch._point)){
			SceneManager.getInstance().goToScene("Login",{logout:true, serverConnected:true});
			return true;
		}
		SceneManager.setActiveScene(this);
		if(cc.rectContainsPoint(this.panels["health_panel"].getBoundingBox(),touch._point)){
			SceneManager.getInstance().goToScene("Main");
			return;
		}
		
		if(this.mapeditor!=null){
			for(var i in this.tiles){
				if(i.substring(0,4)=="tile"){
					if(cc.rectContainsPoint(this.tiles[i].getBoundingBox(),cc.p(touch._point.x,touch._point.y+32))){
						this.mapeditor.tilePressed(this.tiles[i]);
						this.isMapDirty=true;
					}
				}
			}
		}

	},
	
	onKeyUp:function(key){
		switch(key){
			case "C":
				if(this.chatbox.inputBox._parent.getPositionY()!=0){
					this.chatbox.inputBox._parent.setPositionY(0);
				}
				else{
					this.chatbox.inputBox._parent.setPositionY(-this.chatbox.inputBox.getPositionY()+59);
				}
			break;
			case "ENTER":
				if(!this.chatbox.isFocused()) this.chatbox.setFocused(true);
			break;
			case "ESC": SceneManager.getInstance().goToScene("Login",{logout:true,serverConnected:true}); break;
			case "I":
				if(this.inventory){
					this.inventory.willTerminate();
					this.inventory.removeFromParent();
					this.inventory=null;
				} else{
					this.inventory = new InventoryPopup();
					this.inventory.init();
					this.inventory.didBecomeActive();
					this.addChild(this.inventory);
				}
			break;
			case "E":
				if(this.equipment){
					this.equipment.willTerminate();
					this.equipment.removeFromParent();
					this.equipment=null;
				} else{
					this.equipment = new EquipmentPopup();
					this.equipment.init();
					this.equipment.didBecomeActive();
					this.addChild(this.equipment);
				}
				break;
		}
	},
	
	onKeyDown:function(keys){
		var gp = this.playerCharacter.getGridPosition();
		if(gp.x%1==0 && gp.y%1==0){
			switch(keys){
				case "RIGHTARROW": this.playerCharacter.walkTo(gp.x+1,gp.y,this.tiles["tile"+indexFromPos(gp.x+1,gp.y)],"tile"+indexFromPos(gp.x+1,gp.y));  break;
				case "LEFTARROW":  this.playerCharacter.walkTo(gp.x-1,gp.y,this.tiles["tile"+indexFromPos(gp.x-1,gp.y)],"tile"+indexFromPos(gp.x-1,gp.y));   break;
				case "UPARROW": this.playerCharacter.walkTo(gp.x,gp.y+1,this.tiles["tile"+indexFromPos(gp.x,gp.y+1)],"tile"+indexFromPos(gp.x,gp.y+1));  break;
				case "DOWNARROW":  this.playerCharacter.walkTo(gp.x,gp.y-1,this.tiles["tile"+indexFromPos(gp.x,gp.y-1)],"tile"+indexFromPos(gp.x,gp.y-1)); break;
			}
		}
	},
	
	addChatMessage:function(text,fromServer){
		if(!fromServer){
			sendMessageToServer({"chatMessage":text});
			text = this.playerCharacter.getName()+": "+text;
		}
		var currText =[];
		for(var i =0;i<7;i++){
			currText.push(this.panels["chat_panel"]["label"+i].getString());
		}
		this.panels["chat_panel"]["label"+0].setString(text);
		for(var i=1;i<8;i++){
			this.panels["chat_panel"]["label"+i].setString(currText[i-1]);
		}
	},
	
	changePlayerStatus:function(id,status){
		if(this.players[id]){
			this.players[id].updateStatus(status);
		}
	},
	
	runCommand:function(command){
	if(!command){
		return;
	}
	cc.log(command);
		switch(command){
			case "/editmap": if(this.mapeditor){
					this.mapeditor.willTerminate();
					this.mapeditor.removeFromParent();
					this.mapeditor=null;
				} else{
					this.mapeditor = new MapEditor();
					this.mapeditor.init();
					this.mapeditor.didBecomeActive();
					this.addChild(this.mapeditor);
				}
			break;
			case "/help":
			    this.addChatMessage(strings.gameChat.helpText0,true);
				this.addChatMessage(strings.gameChat.helpText1,true);
				this.addChatMessage(strings.gameChat.helpText2,true);
				this.addChatMessage(strings.gameChat.helpText3,true);
				this.addChatMessage(strings.gameChat.helpText4,true);
			break;		
			case "/commands":
				this.addChatMessage(strings.gameChat.commandText0,true);
				this.addChatMessage(strings.gameChat.commandText1,true);
				this.addChatMessage(strings.gameChat.commandText2,true);
				this.addChatMessage(strings.gameChat.commandText3,true);
			break;
			case "/diceroll":
				var number = Math.floor( (Math.random() * 6) + 1);
				number = this.playerCharacter.getName()+" threw a dice and got "+number+"."
				this.addChatMessage(number,true);
				sendMessageToServer({"diceroll":number});
			break;
			case "/coinflip":
				var coin = Math.floor( (Math.random() * 3) + 1) == 1 ? "Heads" : "Tails";
				coin = this.playerCharacter.getName()+" flipped a coin and got "+coin+"."
				this.addChatMessage(coin,true);
				sendMessageToServer({"coinflip":coin});
			break;
			case "/dance":
				var dance = this.playerCharacter.getName()+" dances the dance of his people.";
				this.addChatMessage(dance,true);
				sendMessageToServer({"dance":dance});
			break;
			case "/afk":
				this.playerCharacter.updateStatus("AFK");
				sendMessageToServer({"afk":true});
			break;
		}
	},
	
	
	init:function(withData){
		this._super();
	    // Edit box 1 with default value and background sprite at normal state
		this.chatbox = new ChatBox(this.panels["chat_panel"],cc.size(this.panels["chat_panel"].getContentSize().width-4,25), cc.p(2,this.panels["chat_panel"].getContentSize().height-2), strings.gameChat.defaultChat, cc.c3b(255,255,255), cc.c3b(0,0,0));
		this.chatbox.inputBox._parent.setPositionY(-this.chatbox.inputBox.getPositionY()+59);
		this.addChatMessage(strings.gameChat.introText,true);
		var texture = cc.TextureCache.getInstance().addImage("tiles1.png");
		this.tiles = this.panels["game_panel"]["tiles"];
		this.renderTexture = cc.RenderTexture.create(this.panels["game_panel"].getContentSize().width,this.panels["game_panel"].getContentSize().height);
		this.renderTexture.setPosition(cc.p(Math.floor(this.panels["game_panel"].getContentSize().width/2),Math.floor(this.panels["game_panel"].getContentSize().height/2)));	
	    this.tiles.addChild(this.renderTexture);

		var map_data = {};
		var totaltile = (960/32)*(640/32);
		for(var i=0;i<totaltile;i++){
			map_data["tile"+i]=[
			{texture:"tiles1.png",spriteframe:{x:4,y:10},type:"ground"},
			]
		}
		/*map_data["tile75"]=[
			{texture:"tiles1.png",spriteframe:{x:7,y:15},type:"ground"},
			{texture:"tiles1.png",spriteframe:{x:4,y:9},type:"ground"},
		]
		map_data["tile160"]=[
			{texture:"tiles1.png",spriteframe:{x:7,y:17},type:"ground"},
			{texture:"tiles1.png",spriteframe:{x:4,y:9},type:"ground"},
		]*/
		
		this.map = GameMap.create();
		this.map.setupTiles(map_data,this.tiles);
		
		this.players=[];
		
		
		
		var withData ={
			name: withData.username,
			isPlayer:true,
			stats: {
				"health":{level:1,value:100,maxval:200,maxlvl:900},
				"mana":{level:1,value:100,maxval:200,maxlvl:99},
			},
			textureName: "sprites1.png",
			spriteId: 1,
		};
		this.playerCharacter = PlayerCharacter.create(withData);
		this.playerCharacter.setPosition(320,320);
		this.addChild(this.playerCharacter);
		sendMessageToServer({"moveTo":((this.playerCharacter.getGridPosition().x) + ((this.playerCharacter.getGridPosition().y) * gridWidth))});
		
		
		this.scheduleOnce(this.setDirty,0.5)
		this.scheduleOnce(this.setChatDefault,0.1);	
		this.schedule(this.storedMessages);		
	},
	
	setDirty:function(){
		this.isMapDirty=true;
	},
	
	setChatDefault:function(){
		this.chatbox.init();
	},
	
	storedMessages:function(){
		if(storedClientMessages.length>0){
			for(var i=0;i<storedClientMessages.length;i++){
				var msg = JSON.parse(storedClientMessages[i]);
				if(msg["moveTo"] && (!this.players[msg["id"]] || (this.players[msg["id"]] && this.players[msg["id"]].isWalking==false) )) {
					reactToSocketMessage(JSON.stringify(msg));
					storedClientMessages.splice(i,1);
				} else if(!msg["moveTo"]) {
					reactToSocketMessage(JSON.stringify(msg));
					storedClientMessages.splice(i,1);
				}
			}
		}
	},
	
	visit:function(){
		this._super();
		if(this.isMapDirty==true){
			this.renderTexture.beginWithClear(1,1,1,1);
			for(var i in this.tiles){
				if(i.substring(0,4)=="tile"){
				 this.tiles[i].setVisible(true);
				 this.tiles[i].visit();
				 this.tiles[i].setVisible(false);
				}
			}
			this.isMapDirty=false;
			this.renderTexture.end();
		}
	}
	
});
