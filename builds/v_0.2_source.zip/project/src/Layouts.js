var Layouts = cc.Class.extend({
	instance:null,
	nodes:null,
	
	ctor:function(){
		var itemBox = {
			size: cc.size(32,32),
			bg: cc.c4b(140,140,140,200),
			position: cc.p(0,0),
		};
		
		var chat_panel ={
			size: cc.size(400,150),
			bg: cc.c4b(0,0,0,255),
			opacity: 127,
			position: cc.p(0,-200),
			children:{
				"label7":{
					label:"",
					position:cc.p(5,0),
					anchorPoint:cc.p(0,0),
				},
				"label6":{
					label:"",
					position:cc.p(5,15),
					anchorPoint:cc.p(0,0),
				},
				"label5":{
					label:"",
					position:cc.p(5,30),
					anchorPoint:cc.p(0,0),
				},
				"label4":{
					label:"",
					position:cc.p(5,45),
					anchorPoint:cc.p(0,0),
				},
				"label3":{
					label:"",
					position:cc.p(5,60),
					anchorPoint:cc.p(0,0),
				},				
				"label2":{
					label:"",
					position:cc.p(5,75),
					anchorPoint:cc.p(0,0),
				},				
				"label1":{
					label:"",
					position:cc.p(5,90),
					anchorPoint:cc.p(0,0),
				},
				"label0":{
					label:"",
					position:cc.p(5,105),
					anchorPoint:cc.p(0,0),
				},
			}
		};	
		
		var healthBox={
			size: cc.size(290,20),
			bg: cc.c4b(255,0,0,200),
			position: cc.p(2,2),
		};
		
		var equipment_panel = {
				"head": merge_objects(itemBox,{ position:cc.p(88,128)}),
				"body": merge_objects(itemBox,{ position: cc.p(88,88)}),
				"legs": merge_objects(itemBox,{ position: cc.p(88,48)}),
				"feet": merge_objects(itemBox,{ position: cc.p(88,8)}),
				"weapon": merge_objects(itemBox,{ position: cc.p(48,88)}),
				"shield": merge_objects(itemBox,{ position: cc.p(128,88)}),
				"ammo": merge_objects(itemBox,{ position: cc.p(8,128)}),
		}
		 

		 
		var health_panel ={
			position: cc.p(0,640-60),
			children:{
				"health": merge_objects(healthBox, { position: cc.p(5,5)}),
				"mana": merge_objects(healthBox, { position: cc.p(5,30)}),
			}
		}
		health_panel.children["mana"].bg = cc.c4b(0,0,255,200);
		
		var inventory_panel = {};
		for(var x=0;x<5;x++){
			for(var y=0;y<8;y++){
				inventory_panel[(5 * y + x)+""]=merge_objects(itemBox,{ position: cc.p((x*40)+8,(((8-1)-y)*40)+8)});
			}
		}
		
		
		var cellsize = 32;
		
		var gamePanelSize = cc.size(960,640);
		var gridSize = cc.size(Math.floor(gamePanelSize.width/cellsize),Math.floor(gamePanelSize.height/cellsize));
		var gameTiles={
			children:{},
			anchorPoint:cc.p(0,0),
			position:cc.p(0,0),
		};
		
		
		for(var i=0;i<gridSize.width;i++){
			for(var j=0;j<gridSize.height;j++){
				var index= (i + j*gridSize.width);
				gameTiles.children["tile"+index] = {
					size:cc.size(cellsize,cellsize),
					anchorPoint:cc.p(0,0),
					color:cc.c4b(255,255,255,255),
					position:cc.p(i*cellsize,((gridSize.height)-j)*cellsize),
					isGameTile:true,
					tileXY: cc.p(j,i),
					visible:false,
				};
			}
		}
	
		this.nodes= {
			"Equipment":{
				position:cc.p(100,300),
				children:{	
					"main_panel":{
						anchorPoint:cc.p(0,0),
						position: cc.p(0,0),
						size: cc.size(168,168),
						bg: cc.c4b(255,255,255,200),
						children: equipment_panel,
					},
					"control_panel":{
						anchorPoint:cc.p(0,0),
						position: cc.p(0,168),
						size: cc.size(168,32),
						bg: cc.c4b(255,0,0,200),
						children:{	
							"header":{
								label:"Equipment",
								fontSize:20,
								anchorPoint:cc.p(0,0.5),
								position:cc.p(8,16),
							}
						}
					},
				}	
			},
			"Inventory":{
				position:cc.p(300,300),
				children:{	
					"main_panel":{
						anchorPoint:cc.p(0,0),
						position: cc.p(0,0),
						size: cc.size(208,328),
						bg: cc.c4b(255,255,255,200),
						children: inventory_panel,
					},
					"control_panel":{
						anchorPoint:cc.p(0,0),
						position: cc.p(0,328),
						size: cc.size(208,32),
						bg: cc.c4b(255,0,0,200),
						children:{	
							"header":{
								label:"Inventory",
								fontSize:20,
								anchorPoint:cc.p(0,0.5),
								position:cc.p(8,16),
							}
						}
					},
				}	
			},
			"MapEditor":{
				position:cc.p(300,10),
				children:{	
					"main_panel":{
						anchorPoint:cc.p(0,0),
						position: cc.p(0,0),
						size: cc.size(512,544),
						bg: cc.c4b(0,0,0,255),
						children: {
							"tiles" : {
								anchorPoint:cc.p(0,1),
								position:cc.p(0,480),
								texture:"tiles1.png",
							},
							"deletebtn" : {
								position:cc.p(0,480),
								size:cc.size(32,32),
								bg: cc.c4b(255,255,255,255),
								anchorPoint:cc.p(0,0),
								children:{
									"text":{
										label:"Erase",
										fontSize:12,
										anchorPoint:cc.p(0,1),
										position:cc.p(0,32),
										color:cc.c3b(0,0,0),
									}
								}
							},
							"highlightnode" : {
								anchorPoint:cc.p(0,0),
								position:cc.p(0,0),
								size:cc.size(32,32),
								bg:cc.c4b(255,100,100,255),
							},
							"selectednode" : {
								anchorPoint:cc.p(0,0),
								position:cc.p(0,0),
								size:cc.size(32,32),
								bg:cc.c4b(100,255,100,255),
							}
						}
					},
					"control_panel":{
						anchorPoint:cc.p(0,0),
						position: cc.p(0,512),
						size: cc.size(512,32),
						bg: cc.c4b(255,0,0,200),
						children:{	
							"header":{
								label:"Map Editor",
								fontSize:20,
								anchorPoint:cc.p(0,0.5),
								position:cc.p(8,16),
							}
						}
					},
				}	
			},
			"Game":{
				children:{	
					"game_panel":{
						anchorPoint:cc.p(0,0),
						size: gamePanelSize,
						bg: cc.c4b(0,0,0,255),
						children:{
							"tiles": cloneObj(gameTiles),
						}
					},
					"inventory_panel": inventory_panel,
					"health_panel": health_panel,
					"chat_panel": chat_panel,
					"logout_button":{
						position:cc.p(860,620),
						size:cc.size(100,20),
						bg:cc.c4b(0,0,0,127),
						children:{
							"Logout":{
								label:"Logout",
								color:cc.c3b(255,255,255),
								anchorPoint:cc.p(0.5,0.5),
								position:cc.p(50,10),
							}
						}
					}
				}	
			},
			"Login":{
				children:{	
					"name_entry":{
						size: cc.size(300,30),
						position: cc.p(325,300),
					},
					"go_button":{
						position: cc.p(420,220),
						size: cc.size(120,40),
						bg: cc.c4b(0,0,0,255),
						children:{
							"label":{
								label:"Play",
								fontSize:20,
								color:cc.c3b(255,255,255),
								anchorPoint:cc.p(0.5,0.5),
								position:cc.p(60,20),
							}
						}
					},
					"server_message":{
						label:"",
						fontSize:16,
						color:cc.c3b(127,0,0),
						anchorPoint:cc.p(0,0),
						position:cc.p(327,325),
					},
					"server_activity":{
						position:cc.p(860,620),
						size:cc.size(100,20),
						bg:cc.c4b(255,255,0,127),
						children:{
							"label":{
								label:"Server: Offline",
								color:cc.c3b(255,0,0),
								anchorPoint:cc.p(0.5,0.5),
								position:cc.p(50,10),
							}
						}
					}
				}	
			}
		};
	},
	
	init:function(){
	},
	
	getNode:function(request,parent){
		if(parent){
			var data = parent[request];
		} else{
			var data = this.nodes[request];
		}
		if(typeof(data.isGameTile)!='undefined'){
			var node = GameTile.Create(data.tileXY);
		}else if(typeof(data.bg)!='undefined'){
			var layerSize = data.size ? data.size : cc.size(100,100);
			var node = cc.LayerColor.create(data.bg,layerSize.width,layerSize.height);
		} else if(typeof(data.texture)!='undefined'){
			var node = cc.Sprite.createWithTexture(cc.TextureCache.getInstance().addImage(data.texture));
		} else if(typeof(data.label)!='undefined'){
			var font = data.font ? data.fontFace : "Arial";
			var size = data.fontSize ? data.fontSize : 14;
			var node = cc.LabelTTF.create(data.label,font,size);
		} else {
			var node = cc.Node.create();
		}
		
		if(typeof(data.size)!='undefined'){
			node.setContentSize(Math.floor(data.size.width),Math.floor(data.size.height));
		}
		if(typeof(data.position)!='undefined'){
			node.setPosition(cc.p(Math.floor(data.position.x),Math.floor(data.position.y)));
		}
		if(typeof(data.visible)!='undefined'){
			node.setVisible(data.visible);
		}
		if(typeof(data.anchorPoint)!='undefined'){
			node.setAnchorPoint(data.anchorPoint);
		}
		if(typeof(data.opacity)!='undefined'){
			node.setOpacity(data.opacity);
		}
		if(typeof(data.color)!='undefined'){
			node.setColor(data.color);
		}
		if(typeof(data.children)!='undefined'){
			for(var i in data.children){
				node[i] = this.getNode(i,data.children);
				node.addChild(node[i]);
			}
		}
		return node;
	},

});
Layouts.getInstance = function(){
	if(this.instance==null){
		this.instance = new Layouts();
	}
	return this.instance;
};