var GameTile = cc.Sprite.extend({
	layers:null,
	position:null,
	string:null,
	type:null,
	
	ctor:function(){
		this._super();
	},
	
	init:function(){
		this.layers=[];
		this._super();
		this.string = cc.LabelTTF.create("","Arial",16);
		this.string.setAnchorPoint(0,0);
		this.addChild(this.string);
		

		this.setType(0);
	},
	
	pushLayer:function(_texture,_tilePos,_type){
		var texture = cc.TextureCache.getInstance().addImage(_texture);
		var sprite = cc.Sprite.createWithTexture(texture);
		sprite.setTextureRect(cc.rect(Math.floor(32*_tilePos.x),Math.floor(32*_tilePos.y),32,32));
		sprite.setColor(cc.c4b(255,255,255,255));
		sprite.setAnchorPoint(0,1),
		this.addChild(sprite);
		this.layers.push({image:sprite,type:_type});
	},
	
	topLayer:function(){
		this.layers[this.layers.length-1];
	},
	
	popLayer:function(){
		if(this.layers.length>0){
			this.layers[this.layers.length-1].image.removeFromParent();
			this.layers.splice(this.layers.length-1,1);
		}
	},
	
	setType:function(_in){
		this.type=_in;
		switch(this.type){
			case 0: this.string.setString(""); break;
			case 1: this.string.setString("BLK"); break;
			case 2: this.string.setString("SPW"); break;	
			case 3: this.string.setString("WRP"); break;	
			case 4: this.string.setString("SGN"); break;	
			case 5: this.string.setString("SCR"); break;	
			case 6: this.string.setString("SKL"); break;
		}
	},
	
	setStringVisible:function(_in){
		this.string.setVisible(_in);
				this.string.setColor(255,0,0);
	},
	
	getType:function(){
		return this.type;
	},
	
});

GameTile.Create=function(x,y){
	var tile = new GameTile();
	tile.init();
	tile.position = cc.p(x,y);
	return tile;
};