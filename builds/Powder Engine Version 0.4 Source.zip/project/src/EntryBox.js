var EntryBox = InputBox.extend({
	hasEntry:false,

    editBoxEditingDidBegin: function (editBox) {
		editBox.setText("");
    },

    editBoxEditingDidEnd: function (editBox) {
		if(!editBox.getText().length>0){
			editBox.setText(this.inputBox.defaultText);
			this.hasEntry=false;
			return;
		}
		this.hasEntry=true;
    },
	
    editBoxTextChanged: function (editBox, text) {
		editBox.setText(text);
		this.hasEntry=true;
    },
	
	_getEditBoxName:function(){
		return "name_entry";
	},
	
	getText:function(){
		if(this.hasEntry==true || (this.defaultFine==true && this.inputBox.getText().length>0)){
			return this.inputBox.getText();
		}
		return null;
	},
	
	setDefaultFineFlag:function(value){
		this.defaultFine=value;
	},
	

	init:function(){
    },
});