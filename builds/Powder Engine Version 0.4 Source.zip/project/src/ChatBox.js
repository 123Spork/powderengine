var ChatBox = InputBox.extend({
    editBoxEditingDidBegin: function (editBox) {
		editBox.setText("");
    },

    editBoxEditingDidEnd: function (editBox,ignore) {
		if(!ignore){
			if(editBox.getText().substring(0,1)=="/"){
				this.runChatCommand(editBox.getText());
			}
			else if(editBox.getText().length>0){
				this.addChatMessage(editBox.getText());
			}
		}
		editBox.setText(strings.gameChat.defaultChat);
        //cc.log("chatBox " + this._getEditBoxName(editBox) + " DidEnd !");
    },
	
	runChatCommand:function(command){
		SceneManager.getInstance().currentScene.runCommand(command);
	},
	
	addChatMessage:function(msg){
		SceneManager.getInstance().currentScene.addChatMessage(msg);
	},

    editBoxTextChanged: function (editBox, text) {
		editBox.setText(text);
        cc.log("chatBox " + this._getEditBoxName(editBox) + ", TextChanged, text: " + text);
    },

  //  editBoxReturn: function (editBox) {
      //  cc.log("chatBox " + this._getEditBoxName(editBox) + " was returned !");
    //},	
	
	_getEditBoxName:function(){
		return "chatbox";
	},
});