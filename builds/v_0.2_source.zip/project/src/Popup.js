Popup = Scene.extend({
prevMovPos:null,

init:function(){
	this.sceneIdentifier = this.getIdentifier();
	this._super();	
	SceneManager.setActiveScene(this);
	this.setupPopup();
},

exitButtonPressed:function(){
	this.removeFromParent();
},

onTouchBegan:function(touch){
	if(cc.rectContainsPoint(cc.rect(this.panels.getPosition().x,this.panels.getPosition().y+this.panels["control_panel"].getPosition().y,this.panels["control_panel"].getContentSize().width,this.panels["control_panel"].getContentSize().height),touch._point)){
		this.prevMovPos=this.panels.convertTouchToNodeSpace(touch);
		return true;
	}
	return false;
},

savePopupPoint:function(id){
	cc.log("WOULD SAVE HERE!");
},

onTouchMoved:function(touch){
	if(this.prevMovPos){
		var pt=touch._point;
		this.panels.setPosition(cc.p(pt.x-this.prevMovPos.x,pt.y-this.prevMovPos.y));
		return true;
	}
},

onTouchEnded:function(touch){
	this.prevMovPos=null;
},

setupPopup:function(){
	cc.log("Ovveride setupPopup");
},

getIdentifier:function(){
	cc.log("No id given... using default 'Popup'");
	return "Popup";
},

onTouchEnded:function(touch){
	this.savePopupPoint(this.getIdentifier);
},

});

InventoryPopup = Popup.extend({

	getIdentifier:function(){
		return "Inventory";
	},

});

EquipmentPopup = Popup.extend({

	getIdentifier:function(){
		return "Equipment";
	},

});

MapEditor = Popup.extend({
	map:null,
	editMode:"tiles",
	isDelete:false,
	getIdentifier:function(){
		return "MapEditor";
	},
	
	init:function(_map){
		this._super();
		this.map =_map;
		//for(var i in this.map.tiles){
		//	this.map.tiles.setStringVisible(true);
	//	}
	},
	
	didBecomeActive:function(){
		this._super();
		this.panels["main_panel"]["highlightnode"].setOpacity(0);
		this.panels["main_panel"]["selectednode"].setOpacity(0);
	},
	
	willTerminate:function(){
		//for(var i in this.map.tiles){
		//	this.map.tiles.setStringVisible(false);
	//	}
	},
	
	onMouseMoved:function(pos){
		this.panels["main_panel"]["highlightnode"].setOpacity(0);
		var truePos = this.panels["main_panel"].convertToNodeSpace(pos);
		if(truePos.x>=0 && truePos.y>=0 && truePos.x<=this.panels["main_panel"]["tiles"].getContentSize().width && truePos.y<=this.panels["main_panel"]["tiles"].getContentSize().height){
			truePos.x = truePos.x-(truePos.x%32);
			truePos.y = truePos.y-(truePos.y%32);
			
			this.panels["main_panel"]["highlightnode"].setOpacity(127);
			this.panels["main_panel"]["highlightnode"].setPosition(truePos);
			return true;
		} 
	},
	
	onTouchBegan:function(touch){
		if(this._super(touch)){
			return true;
		}
		SceneManager.setActiveScene(this);
		var pos = touch._point;
		var truePos = this.panels["main_panel"].convertToNodeSpace(pos);
		if(truePos.x>=0 && truePos.y>=0 && truePos.x<=this.panels["main_panel"]["tiles"].getContentSize().width && truePos.y<=this.panels["main_panel"]["tiles"].getContentSize().height){
			truePos.x = truePos.x-(truePos.x%32);
			truePos.y = truePos.y-(truePos.y%32);
			
			if(this.panels["main_panel"]["selectednode"].getPositionX()!=truePos.x || this.panels["main_panel"]["selectednode"].getPositionY()!=truePos.y){
				this.panels["main_panel"]["selectednode"].setOpacity(127);
				this.panels["main_panel"]["selectednode"].setPosition(truePos);
			} else{
				this.panels["main_panel"]["selectednode"].setOpacity(0);
			}
			return true;
		} 
		
		var globalErasePos = this.panels["main_panel"]["deletebtn"].convertToWorldSpace(cc.p(0,0));
		if(cc.rectContainsPoint(cc.rect(globalErasePos.x,globalErasePos.y,this.panels["main_panel"]["deletebtn"].getContentSize().width,this.panels["main_panel"]["deletebtn"].getContentSize().height),touch._point)){
			this.isDelete=!this.isDelete;
			if(this.isDelete){
				this.panels["main_panel"]["deletebtn"].setColor(cc.c4b(255,0,0,255));
			} else{
				this.panels["main_panel"]["deletebtn"].setColor(cc.c4b(255,255,255,255));
			}
			return true;
		}
		
		/*var globalErasePos = this.panels["main_panel"]["deletebtn"].convertToWorldSpace(cc.p(0,0));
		if(cc.rectContainsPoint(cc.rect(globalErasePos.x,globalErasePos.y,this.panels["main_panel"]["deletebtn"].getContentSize().width,this.panels["main_panel"]["deletebtn"].getContentSize().height),touch._point)){
			this.isDelete=!this.isDelete;
			if(this.isDelete){
				this.panels["main_panel"]["deletebtn"].setColor(cc.c4b(255,0,0,255));
			} else{
				this.panels["main_panel"]["deletebtn"].setColor(cc.c4b(255,255,255,255));
			}
			return true;
		}*/
		return false;
	},	
	
	tilePressed:function(tile){
		if(this.isDelete){
			switch(this.editMode){
				case "tiles":
					tile.popLayer();
				break;
				case "blocking":
					tile.setType(0);
					tile.setStringVisible(false);
				break;
			}
		} else{
			switch(this.editMode){
				case "tiles":
					if(this.panels["main_panel"]["selectednode"].getOpacity()!=0){
						tile.pushLayer("tiles1.png",cc.p(this.panels["main_panel"]["selectednode"].getPositionX()/32,14-(this.panels["main_panel"]["selectednode"].getPositionY()/32)),"ground");
					}
				break;
				case "blocking":
					tile.setType(1);
					tile.setStringVisible(true);
				break;
			}
		}
	}
});

