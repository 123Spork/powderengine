var js = js || {};
js.project = {
    Character_js : '[%project%]src/Character.js',
    ChatBox_js : '[%project%]src/ChatBox.js',
    client_js : '[%project%]src/client.js',
    EntryBox_js : '[%project%]src/EntryBox.js',
    GameScene_js : '[%project%]src/GameScene.js',
    GameTile_js : '[%project%]src/GameTile.js',
    InputBox_js : '[%project%]src/InputBox.js',
    Layouts_js : '[%project%]src/Layouts.js',
    Login_js : '[%project%]src/Login.js',
    MainScene_js : '[%project%]src/MainScene.js',
    map_js : '[%project%]src/map.js',
    Popup_js : '[%project%]src/Popup.js',
    Scene_js : '[%project%]src/Scene.js',
    SceneManager_js : '[%project%]src/SceneManager.js',
    StatsController_js : '[%project%]src/StatsController.js',
    Strings_js : '[%project%]src/Strings.js',
    Utils_js : '[%project%]src/Utils.js'
};