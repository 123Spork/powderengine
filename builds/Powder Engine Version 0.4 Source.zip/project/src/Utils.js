var keyMap = {};

document.getElementById("gameCanvas").onkeydown = function (event) {
	event.preventDefault();
	keyMap[event.keyCode]=true;
};

window.onbeforeunload = function(event){
	sendMessageToServer({"disconnect":true});
};

window.onfocus = function () {
	var moveTos = [];
	for(var i=storedClientMessages.length-1;i>=0;i--){
		var msg = JSON.parse(storedClientMessages[i]);
		if(msg["moveTo"] && !moveTos[msg["id"]]) {
			moveTos[msg["id"]]=true;
			msg["setTo"]=msg["moveTo"];
			msg["moveTo"]=null;
			storedClientMessages[i]=JSON.stringify(msg);
		}
		else if(msg["moveTo"] && moveTos[msg["id"]]){
			storedClientMessages.splice(i,1);
		}
	}
}; 

document.getElementById("gameCanvas").onkeyup = function (event) {
	keyMap[event.keyCode]=false;
	if(SceneManager.getInstance().currentScene!=null){
		event.stopPropagation();
		var button = null;	
		switch(event.keyCode){
			case 8: button="BACKSPACE"; break;
			case 9: button="TAB"; break;
			case 13: button="ENTER"; break;
			case 16: button="SHIFT"; break;
			case 17: button="CTRL"; break;
			case 18: button="ALT"; break;
			case 19: button="PAUSE"; break;
			case 20: button="CAPSLOCK"; break;
			case 27: button="ESC"; break;
			case 32: button="SPACE";break;
			case 33: button="PAGEUP";break;
			case 34: button="PAGEDOWN"; break;
			case 35: button="END";break;
			case 37: button="LEFTARROW"; break;
			case 38: button="UPARROW"; break;
			case 39: button="RIGHTARROW"; break;
			case 40: button="DOWNARROW"; break;
			case 45: button="INSERT"; break;
			case 46: button="DELETE"; break;
		}
		if(button==null){
			if((event.keyCode>47 && event.keyCode<58) || (event.keyCode>64 && event.keyCode<91)){
				button = String.fromCharCode(event.keyCode);
			}
		}
		if(button!=null){
			SceneManager.getInstance().currentScene.onKeyUp(button);
		}
	}
};

function cloneObj(obj) {
    var clone = {};

    for (var i in obj) {
        if (obj[i] && typeof obj[i] == 'object') {
            clone[i] = cloneObj(obj[i]);
        } else {
            clone[i] = obj[i];
        }
    }
    return clone;
};


function requestLayout(delegate){
	var layoutObject = delegate.getLayoutObject();
	return getLayoutNodes(layoutObject,"panels");
};

function getLayoutNodes(nodes,request,parent){
		if(parent){
			var data = parent[request];
		} else{
			var data = nodes[request];
		}
		if(typeof(data.isGameTile)!='undefined'){
			var node = GameTile.Create(data.tileXY);
		}else if(typeof(data.bg)!='undefined'){
			var layerSize = data.size ? data.size : cc.size(100,100);
			var node = cc.LayerColor.create(data.bg,layerSize.width,layerSize.height);
		} else if(typeof(data.texture)!='undefined'){
			var node = cc.Sprite.createWithTexture(cc.TextureCache.getInstance().addImage(data.texture));
		} else if(typeof(data.label)!='undefined'){
			var font = data.font ? data.fontFace : "Arial";
			var size = data.fontSize ? data.fontSize : 14;
			var node = cc.LabelTTF.create(data.label,font,size);
		} else {
			var node = cc.Node.create();
		}
		
		if(typeof(data.size)!='undefined'){
			node.setContentSize(Math.floor(data.size.width),Math.floor(data.size.height));
		}
		if(typeof(data.position)!='undefined'){
			node.setPosition(cc.p(Math.floor(data.position.x),Math.floor(data.position.y)));
		}
		if(typeof(data.visible)!='undefined'){
			node.setVisible(data.visible);
		}
		if(typeof(data.anchorPoint)!='undefined'){
			node.setAnchorPoint(data.anchorPoint);
		}
		if(typeof(data.opacity)!='undefined'){
			node.setOpacity(data.opacity);
		}
		if(typeof(data.color)!='undefined'){
			node.setColor(data.color);
		}
		if(typeof(data.children)!='undefined'){
			for(var i in data.children){
				node[i] = getLayoutNodes(nodes,i,data.children);
				node.addChild(node[i]);
			}
		}
		return node;
};

var gamePanelSize = cc.size(960,640);
var cellsize = 32;
var gridHeight = Math.floor(gamePanelSize.height/cellsize);
var gridWidth = Math.floor(gamePanelSize.width/cellsize);

function indexFromPos(x,y){
	return (gridWidth*((gridHeight)-y))+x;
};

function merge_objects(obj1,obj2){
	var obj3 = {};
	for (var attrname in obj1) { obj3[attrname] = cloneObj(obj1[attrname]); }
	for (var attrname in obj2) { obj3[attrname] = cloneObj(obj2[attrname]); }
	return obj3;
};