var keyMap = {};

document.getElementById("gameCanvas").onkeydown = function (event) {
	event.preventDefault();
	keyMap[event.keyCode]=true;
};

window.onbeforeunload = function(event){
	sendMessageToServer({"disconnect":true});
};

document.getElementById("gameCanvas").onkeyup = function (event) {
	keyMap[event.keyCode]=false;
	if(SceneManager.getInstance().currentScene!=null){
		event.stopPropagation();
		var button = null;	
		switch(event.keyCode){
			case 8: button="BACKSPACE"; break;
			case 9: button="TAB"; break;
			case 13: button="ENTER"; break;
			case 16: button="SHIFT"; break;
			case 17: button="CTRL"; break;
			case 18: button="ALT"; break;
			case 19: button="PAUSE"; break;
			case 20: button="CAPSLOCK"; break;
			case 27: button="ESC"; break;
			case 32: button="SPACE";break;
			case 33: button="PAGEUP";break;
			case 34: button="PAGEDOWN"; break;
			case 35: button="END";break;
			case 37: button="LEFTARROW"; break;
			case 38: button="UPARROW"; break;
			case 39: button="RIGHTARROW"; break;
			case 40: button="DOWNARROW"; break;
			case 45: button="INSERT"; break;
			case 46: button="DELETE"; break;
		}
		if(button==null){
			if((event.keyCode>47 && event.keyCode<58) || (event.keyCode>64 && event.keyCode<91)){
				button = String.fromCharCode(event.keyCode);
			}
		}
		if(button!=null){
			SceneManager.getInstance().currentScene.onKeyUp(button);
		}
	}
};

function cloneObj(obj) {
    var clone = {};

    for (var i in obj) {
        if (obj[i] && typeof obj[i] == 'object') {
            clone[i] = cloneObj(obj[i]);
        } else {
            clone[i] = obj[i];
        }
    }
    return clone;
};

var gridHeight = Math.floor(640/32);
var gridWidth = Math.floor(960/32);

function indexFromPos(x,y){
	return (gridWidth*((gridHeight)-y))+x;
};

function merge_objects(obj1,obj2){
	var obj3 = {};
	for (var attrname in obj1) { obj3[attrname] = cloneObj(obj1[attrname]); }
	for (var attrname in obj2) { obj3[attrname] = cloneObj(obj2[attrname]); }
	return obj3;
};