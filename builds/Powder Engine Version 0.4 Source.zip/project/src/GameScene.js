var GameChat;

var GameScene = Scene.extend({
	inventory:null,
	equipment:null,
	mapeditor:null,
	itemeditor:null,
	
	ctor:function(){
		this._super();
	},
	
	getLayoutObject:function(){
		var health_panel ={
			position: cc.p(0,640-60),
			children:{
				"health": {
					size: cc.size(290,20),
					bg: cc.c4b(255,0,0,200),
					position: cc.p(5,5)
				},
				"mana": { 
					size: cc.size(290,20),
					position: cc.p(5,30),
					bg:cc.c4b(0,0,255,200)
				}
			}
		}
	
	
		var chat_panel ={
			size: cc.size(400,150),
			bg: cc.c4b(0,0,0,255),
			opacity: 127,
			position: cc.p(0,-200),
			children:{
				"label7":{
					label:"",
					position:cc.p(5,0),
					anchorPoint:cc.p(0,0),
				},
				"label6":{
					label:"",
					position:cc.p(5,15),
					anchorPoint:cc.p(0,0),
				},
				"label5":{
					label:"",
					position:cc.p(5,30),
					anchorPoint:cc.p(0,0),
				},
				"label4":{
					label:"",
					position:cc.p(5,45),
					anchorPoint:cc.p(0,0),
				},
				"label3":{
					label:"",
					position:cc.p(5,60),
					anchorPoint:cc.p(0,0),
				},				
				"label2":{
					label:"",
					position:cc.p(5,75),
					anchorPoint:cc.p(0,0),
				},				
				"label1":{
					label:"",
					position:cc.p(5,90),
					anchorPoint:cc.p(0,0),
				},
				"label0":{
					label:"",
					position:cc.p(5,105),
					anchorPoint:cc.p(0,0),
				},
			}
		};	
	
	
		 return {
		 "panels":{
			 children:{	
				"health_panel": health_panel,
				"chat_panel": chat_panel,
				"logout_button":{
					position:cc.p(860,620),
					size:cc.size(100,20),
					bg:cc.c4b(0,0,0,127),
					children:{
						"Logout":{
							label:"Logout",
							color:cc.c3b(255,255,255),
							position:cc.p(50,10),
						}
					}
				}
			}
			}
		}
	},

	
	setServerConnected:function(active){
		if(active==false){
			this.destroyGame();
			SceneManager.getInstance().goToScene("Login",{serverConnected:false});
		}
	},
	
	//onMouseMoved:function(pos){

	//},
	
	destroyGame:function(){
		GameMap.destroy();
		GameMap.getInstance().removeFromParent();
		GameMap.setInstanceNull();
		PlayersController.destroy();
		PlayersController.setInstanceNull();
	},

	onTouchBegan:function(touch){
		if(cc.rectContainsPoint(cc.rect(this.panels["logout_button"].getPositionX(),this.panels["logout_button"].getPositionY(),this.panels["logout_button"].getContentSize().width,this.panels["logout_button"].getContentSize().height),touch._point)){
			this.destroyGame();
			SceneManager.getInstance().goToScene("Login",{logout:true, serverConnected:true});
			return true;
		}
		SceneManager.setActiveScene(this);
		if(cc.rectContainsPoint(this.panels["health_panel"].getBoundingBox(),touch._point)){
			SceneManager.getInstance().goToScene("Main");
			return true;
		}
	},
	
	onKeyUp:function(key){
		switch(key){
			case "C":
				if(GameChat.inputBox._parent.getPositionY()!=0){
					GameChat.inputBox._parent.setPositionY(0);
				}
				else{
					GameChat.inputBox._parent.setPositionY(-GameChat.inputBox.getPositionY()+59);
				}
			break;
			case "ENTER":
				if(!GameChat.isFocused()) GameChat.setFocused(true);
			break;
			case "ESC": this.destroyGame(); SceneManager.getInstance().goToScene("Login",{logout:true,serverConnected:true}); break;
			case "I":
				if(this.inventory){
					this.inventory.willTerminate();
					this.inventory.removeFromParent();
					this.inventory=null;
				} else{
					this.inventory = new InventoryPopup();
					this.inventory.init();
					this.inventory.didBecomeActive();
					this.addChild(this.inventory);
				}
			break;
			case "E":
				if(this.equipment){
					this.equipment.willTerminate();
					this.equipment.removeFromParent();
					this.equipment=null;
				} else{
					this.equipment = new EquipmentPopup();
					this.equipment.init();
					this.equipment.didBecomeActive();
					this.addChild(this.equipment);
				}
				break;
		}
	},
	
	onKeyDown:function(keys){
		var gp = PlayersController.getYou().getGridPosition();
		if(gp.x%1==0 && gp.y%1==0){
			switch(keys){
				case "RIGHTARROW": PlayersController.getYou().walkTo(gp.x+1,gp.y);  break;
				case "LEFTARROW":  PlayersController.getYou().walkTo(gp.x-1,gp.y);   break;
				case "UPARROW": PlayersController.getYou().walkTo(gp.x,gp.y+1);  break;
				case "DOWNARROW":  PlayersController.getYou().walkTo(gp.x,gp.y-1); break;
			}
		}
	},
	
	addChatMessage:function(text,fromServer){
		if(!fromServer){
			sendMessageToServer({"chatMessage":text});
			text = PlayersController.getYou().getName()+": "+text;
		}
		var currText =[];
		for(var i =0;i<7;i++){
			currText.push(this.panels["chat_panel"]["label"+i].getString());
		}
		this.panels["chat_panel"]["label"+0].setString(text);
		for(var i=1;i<8;i++){
			this.panels["chat_panel"]["label"+i].setString(currText[i-1]);
		}
	},
	
	runCommand:function(command){
	if(!command){
		return;
	}
	cc.log(command);
		switch(command){
			case "/editmap": if(this.mapeditor){
					this.mapeditor.willTerminate();
					this.mapeditor.removeFromParent();
					this.mapeditor=null;
					GameMap.setInteractionDelegate(null);
				} else{
					this.mapeditor = new MapEditor();
					this.mapeditor.init();
					this.mapeditor.didBecomeActive();
					this.addChild(this.mapeditor);
					GameMap.setInteractionDelegate(this.mapeditor);
				}
			break;
			case "/edititems": if(this.itemeditor){
					this.itemeditor.willTerminate();
					this.itemeditor.removeFromParent();
					this.itemeditor=null;
					GameMap.setInteractionDelegate(null);
				} else{
					this.itemeditor = new ItemEditor();
					this.itemeditor.init();
					this.itemeditor.didBecomeActive();
					this.addChild(this.itemeditor);
				}
			break;
			case "/help":
			    this.addChatMessage(strings.gameChat.helpText0,true);
				this.addChatMessage(strings.gameChat.helpText1,true);
				this.addChatMessage(strings.gameChat.helpText2,true);
				this.addChatMessage(strings.gameChat.helpText3,true);
				this.addChatMessage(strings.gameChat.helpText4,true);
			break;		
			case "/commands":
				this.addChatMessage(strings.gameChat.commandText0,true);
				this.addChatMessage(strings.gameChat.commandText1,true);
				this.addChatMessage(strings.gameChat.commandText2,true);
				this.addChatMessage(strings.gameChat.commandText3,true);
			break;
			case "/diceroll":
				var number = Math.floor( (Math.random() * 6) + 1);
				number = PlayersController.getYou().getName()+" threw a dice and got "+number+"."
				this.addChatMessage(number,true);
				sendMessageToServer({"diceroll":number});
			break;
			case "/coinflip":
				var coin = Math.floor( (Math.random() * 3) + 1) == 1 ? "Heads" : "Tails";
				coin = PlayersController.getYou().getName()+" flipped a coin and got "+coin+"."
				this.addChatMessage(coin,true);
				sendMessageToServer({"coinflip":coin});
			break;
			case "/dance":
				var dance = PlayersController.getYou().getName()+" dances the dance of his people.";
				this.addChatMessage(dance,true);
				sendMessageToServer({"dance":dance});
			break;
			case "/afk":
				PlayersController.getYou().updateStatus("AFK");
				sendMessageToServer({"afk":true});
			break;
		}
	},
	
	init:function(withData){
		this._super();
		this.addChild(GameMap.create());
		this.panels.removeFromParent();
		this.addChild(this.panels);		
		GameChat = new ChatBox(this.panels["chat_panel"],cc.size(this.panels["chat_panel"].getContentSize().width-4,25), cc.p(2,this.panels["chat_panel"].getContentSize().height-2), strings.gameChat.defaultChat, cc.c3b(255,255,255), cc.c3b(0,0,0));
		GameChat.inputBox._parent.setPositionY(-GameChat.inputBox.getPositionY()+59);
		this.addChatMessage(strings.gameChat.introText,true);

		GameMap.getInstance().setup(withData.map);
		var withData ={
			name: withData.username,
			isPlayer:true,
			stats: {
				"health":{level:1,value:100,maxval:200,maxlvl:900},
				"mana":{level:1,value:100,maxval:200,maxlvl:99},
			},
			map:1,
			textureName: "sprites1.png",
			spriteId: 1,
		};
		PlayersController.create(this,withData);
		sendMessageToServer({"moveTo":((PlayersController.getYou().getGridPosition().x) + ((PlayersController.getYou().getGridPosition().y) * gridWidth))});
		this.schedule(this.storedMessages);		
	},
	
	storedMessages:function(){
		if(storedClientMessages.length>0){
			for(var i=0;i<storedClientMessages.length;i++){
				var msg = JSON.parse(storedClientMessages[i]);
				if(msg["moveTo"] && (!PlayersController.getPlayer(msg["id"]) || (PlayersController.getPlayer(msg["id"]) && PlayersController.getPlayer(msg["id"]).isWalking==false) )) {
					reactToSocketMessage(JSON.stringify(msg));
					storedClientMessages.splice(i,1);
				} else if(!msg["moveTo"]) {
					reactToSocketMessage(JSON.stringify(msg));
					storedClientMessages.splice(i,1);
				}
			}
		}
	},

	
});
